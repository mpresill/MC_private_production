ALL_TOOLS      += rivet
rivet_EX_INCLUDE := /cvmfs/cms.cern.ch/el8_amd64_gcc12/external/rivet/3.1.8-5dceb340e5307ae5acf02bdab33f804a/include
rivet_EX_LIB := Rivet
rivet_EX_USE := hepmc fastjet fastjet-contrib gsl yoda


ALL_TOOLS      += hector
hector_EX_INCLUDE := /cvmfs/cms.cern.ch/el8_amd64_gcc12/external/hector/1.3.4_patch1-fec9ce210b85f5d78dcdbbc07f49153b/include
hector_EX_LIB := Hector
hector_EX_USE := root_cxxdefaults


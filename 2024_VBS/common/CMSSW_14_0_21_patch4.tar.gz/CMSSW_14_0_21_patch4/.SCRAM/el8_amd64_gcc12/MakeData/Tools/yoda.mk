ALL_TOOLS      += yoda
yoda_EX_INCLUDE := /cvmfs/cms.cern.ch/el8_amd64_gcc12/external/yoda/1.9.8-5880ff218a956cbba021a396b864d30e/include
yoda_EX_LIB := YODA
yoda_EX_USE := root_cxxdefaults


ifeq ($(strip $(DataFormats/Math)),)
DataFormatsMath := self/DataFormats/Math
DataFormats/Math := DataFormatsMath
DataFormatsMath_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
DataFormatsMath_EX_USE := $(foreach d, self cmssw  eigen rootmath DataFormats/Common FWCore/Utilities,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
DataFormatsMath_LCGDICTS  := x 
DataFormatsMath_EX_LIB   := DataFormatsMath
ALL_EXTERNAL_PRODS += DataFormatsMath
DataFormatsMath_CLASS := LIBRARY
DataFormats/Math_relbigobj+=DataFormatsMath
endif
ifeq ($(strip $(RecoTracker/CkfPattern)),)
RecoTrackerCkfPattern := self/RecoTracker/CkfPattern
RecoTracker/CkfPattern := RecoTrackerCkfPattern
RecoTrackerCkfPattern_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerCkfPattern_EX_USE := $(foreach d, self cmssw  root DataFormats/Common DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager Geometry/TrackerGeometryBuilder MagneticField/Engine MagneticField/Records RecoTracker/MeasurementDet RecoTracker/TkDetLayers TrackingTools/KalmanUpdators TrackingTools/MaterialEffects TrackingTools/MeasurementDet TrackingTools/PatternTools TrackingTools/TrackFitters TrackingTools/TrajectoryCleaning TrackingTools/TrajectoryFiltering,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerCkfPattern_EX_LIB   := RecoTrackerCkfPattern
ALL_EXTERNAL_PRODS += RecoTrackerCkfPattern
RecoTrackerCkfPattern_CLASS := LIBRARY
RecoTracker/CkfPattern_relbigobj+=RecoTrackerCkfPattern
endif
ifeq ($(strip $(RecoTrackerCkfPatternPlugins)),)
RecoTrackerCkfPatternPlugins := self/src/RecoTracker/CkfPattern/plugins
RecoTrackerCkfPatternPlugins_LOC_USE := self cmssw  RecoTracker/CkfPattern RecoTracker/MeasurementDet
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerCkfPatternPlugins
RecoTracker/CkfPattern_relbigobj+=RecoTrackerCkfPatternPlugins
endif
ifeq ($(strip $(RecoTracker/NuclearSeedGenerator)),)
RecoTrackerNuclearSeedGenerator := self/RecoTracker/NuclearSeedGenerator
RecoTracker/NuclearSeedGenerator := RecoTrackerNuclearSeedGenerator
RecoTrackerNuclearSeedGenerator_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerNuclearSeedGenerator_EX_USE := $(foreach d, self cmssw  DataFormats/Common DataFormats/GeometryVector DataFormats/TrackReco DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Engine RecoTracker/MeasurementDet RecoTracker/TkDetLayers RecoTracker/TkSeedGenerator TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/MeasurementDet TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit boost,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerNuclearSeedGenerator_EX_LIB   := RecoTrackerNuclearSeedGenerator
ALL_EXTERNAL_PRODS += RecoTrackerNuclearSeedGenerator
RecoTrackerNuclearSeedGenerator_CLASS := LIBRARY
RecoTracker/NuclearSeedGenerator_relbigobj+=RecoTrackerNuclearSeedGenerator
endif
ifeq ($(strip $(RecoTrackerNuclearSeedGeneratorPlugins)),)
RecoTrackerNuclearSeedGeneratorPlugins := self/src/RecoTracker/NuclearSeedGenerator/plugins
RecoTrackerNuclearSeedGeneratorPlugins_LOC_USE := self cmssw  RecoTracker/NuclearSeedGenerator RecoTracker/Record RecoTracker/TrackProducer DataFormats/BeamSpot DataFormats/TrackReco DataFormats/VertexReco
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerNuclearSeedGeneratorPlugins
RecoTracker/NuclearSeedGenerator_relbigobj+=RecoTrackerNuclearSeedGeneratorPlugins
endif
ifeq ($(strip $(RecoTracker/SiTrackerMRHTools)),)
RecoTrackerSiTrackerMRHTools := self/RecoTracker/SiTrackerMRHTools
RecoTracker/SiTrackerMRHTools := RecoTrackerSiTrackerMRHTools
RecoTrackerSiTrackerMRHTools_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerSiTrackerMRHTools_EX_USE := $(foreach d, self cmssw  DataFormats/GeometryVector DataFormats/Math DataFormats/TrackerRecHit2D FWCore/MessageLogger FWCore/Utilities RecoTracker/MeasurementDet RecoTracker/TkDetLayers RecoTracker/TransientTrackingRecHit TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/MeasurementDet TrackingTools/PatternTools TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit TrackingTools/TrackFitters,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerSiTrackerMRHTools_EX_LIB   := RecoTrackerSiTrackerMRHTools
ALL_EXTERNAL_PRODS += RecoTrackerSiTrackerMRHTools
RecoTrackerSiTrackerMRHTools_CLASS := LIBRARY
RecoTracker/SiTrackerMRHTools_relbigobj+=RecoTrackerSiTrackerMRHTools
endif
ifeq ($(strip $(RecoTrackerSiTrackerMRHToolsAuto)),)
RecoTrackerSiTrackerMRHToolsAuto := self/src/RecoTracker/SiTrackerMRHTools/plugins
RecoTrackerSiTrackerMRHToolsAuto_LOC_USE := self cmssw  RecoTracker/Record RecoTracker/SiTrackerMRHTools
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerSiTrackerMRHToolsAuto
RecoTracker/SiTrackerMRHTools_relbigobj+=RecoTrackerSiTrackerMRHToolsAuto
endif
ifeq ($(strip $(RecoTracker/TkTrackingRegions)),)
RecoTrackerTkTrackingRegions := self/RecoTracker/TkTrackingRegions
RecoTracker/TkTrackingRegions := RecoTrackerTkTrackingRegions
RecoTrackerTkTrackingRegions_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerTkTrackingRegions_EX_USE := $(foreach d, self cmssw  clhep boost root FWCore/Framework FWCore/PluginManager FWCore/ParameterSet RecoTracker/Record RecoTracker/TkSeedingLayers RecoTracker/TkMSParametrization RecoTracker/MeasurementDet TrackingTools/PatternTools TrackingTools/TransientTrackingRecHit TrackingTools/MeasurementDet TrackingTools/KalmanUpdators DataFormats/Common DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/Math DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit FWCore/Utilities MagneticField/Engine TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/TrajectoryParametrization TrackingTools/TrajectoryState,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerTkTrackingRegions_LCGDICTS  := x 
RecoTrackerTkTrackingRegions_EX_LIB   := RecoTrackerTkTrackingRegions
ALL_EXTERNAL_PRODS += RecoTrackerTkTrackingRegions
RecoTrackerTkTrackingRegions_CLASS := LIBRARY
RecoTracker/TkTrackingRegions_relbigobj+=RecoTrackerTkTrackingRegions
endif
ifeq ($(strip $(RecoTrackerTkTrackingRegionsPlugins)),)
RecoTrackerTkTrackingRegionsPlugins := self/src/RecoTracker/TkTrackingRegions/plugins
RecoTrackerTkTrackingRegionsPlugins_LOC_USE := self cmssw  CondFormats/SiPixelObjects DataFormats/Candidate DataFormats/L1Trigger DataFormats/MuonDetId Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Records RecoTracker/TkTrackingRegions RecoMuon/TrackingTools clhep
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerTkTrackingRegionsPlugins
RecoTracker/TkTrackingRegions_relbigobj+=RecoTrackerTkTrackingRegionsPlugins
endif
ifeq ($(strip $(RecoTracker/MeasurementDet)),)
RecoTrackerMeasurementDet := self/RecoTracker/MeasurementDet
RecoTracker/MeasurementDet := RecoTrackerMeasurementDet
RecoTrackerMeasurementDet_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerMeasurementDet_EX_USE := $(foreach d, self cmssw  TrackingTools/GeomPropagators CalibFormats/SiStripObjects DataFormats/Common DataFormats/Math DataFormats/SiPixelCluster FWCore/Framework FWCore/ParameterSet TrackingTools/TrajectoryState RecoTracker/TkDetLayers CondFormats/SiStripObjects DataFormats/DetId DataFormats/Phase2TrackerCluster DataFormats/SiPixelDetId DataFormats/SiStripCluster DataFormats/SiStripDetId DataFormats/TrackingRecHit DataFormats/TrajectorySeed DataFormats/TrajectoryState FWCore/Utilities RecoLocalTracker/Phase2TrackerRecHits TrackingTools/DetLayers TrackingTools/MeasurementDet,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerMeasurementDet_LCGDICTS  := x 
RecoTrackerMeasurementDet_EX_LIB   := RecoTrackerMeasurementDet
ALL_EXTERNAL_PRODS += RecoTrackerMeasurementDet
RecoTrackerMeasurementDet_CLASS := LIBRARY
RecoTracker/MeasurementDet_relbigobj+=RecoTrackerMeasurementDet
endif
ifeq ($(strip $(RecoTrackerMeasurementDetPlugins)),)
RecoTrackerMeasurementDetPlugins := self/src/RecoTracker/MeasurementDet/plugins
RecoTrackerMeasurementDetPlugins_LOC_USE := self cmssw  RecoTracker/MeasurementDet RecoLocalTracker/Phase2TrackerRecHits CalibFormats/SiStripObjects CalibTracker/Records CondFormats/DataRecord CondFormats/SiPixelObjects Geometry/TrackerGeometryBuilder TrackingTools/KalmanUpdators RecoTracker/Record RecoTracker/TkDetLayers
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerMeasurementDetPlugins
RecoTracker/MeasurementDet_relbigobj+=RecoTrackerMeasurementDetPlugins
endif
ifeq ($(strip $(RecoTracker/PixelLowPtUtilities)),)
RecoTrackerPixelLowPtUtilities := self/RecoTracker/PixelLowPtUtilities
RecoTracker/PixelLowPtUtilities := RecoTrackerPixelLowPtUtilities
RecoTrackerPixelLowPtUtilities_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerPixelLowPtUtilities_EX_USE := $(foreach d, self cmssw  CondFormats/DataRecord CondFormats/SiPixelObjects CondFormats/SiStripObjects DataFormats/TrackerCommon FWCore/Framework FWCore/ParameterSet FWCore/PluginManager FWCore/Utilities Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Records RecoTracker/PixelTrackFitting RecoTracker/PixelSeeding TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryFiltering,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerPixelLowPtUtilities_EX_LIB   := RecoTrackerPixelLowPtUtilities
ALL_EXTERNAL_PRODS += RecoTrackerPixelLowPtUtilities
RecoTrackerPixelLowPtUtilities_CLASS := LIBRARY
RecoTracker/PixelLowPtUtilities_relbigobj+=RecoTrackerPixelLowPtUtilities
endif
ifeq ($(strip $(RecoPixelVertexingPixelLowPtUtilitiesPlugins)),)
RecoPixelVertexingPixelLowPtUtilitiesPlugins := self/src/RecoTracker/PixelLowPtUtilities/plugins
RecoPixelVertexingPixelLowPtUtilitiesPlugins_LOC_USE := self cmssw  DataFormats/VertexReco RecoTracker/PixelLowPtUtilities
ALL_EXTERNAL_PLUGIN_PRODS += RecoPixelVertexingPixelLowPtUtilitiesPlugins
RecoTracker/PixelLowPtUtilities_relbigobj+=RecoPixelVertexingPixelLowPtUtilitiesPlugins
endif
ifeq ($(strip $(RecoTracker/PixelSeeding)),)
RecoTrackerPixelSeeding := self/RecoTracker/PixelSeeding
RecoTracker/PixelSeeding := RecoTrackerPixelSeeding
RecoTrackerPixelSeeding_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerPixelSeeding_LOC_FLAGS_CXXFLAGS   := -fno-math-errno
RecoTrackerPixelSeeding_EX_USE := $(foreach d, self cmssw  root FWCore/Framework FWCore/ParameterSet FWCore/PluginManager Geometry/Records Geometry/TrackerGeometryBuilder RecoTracker/TkHitPairs RecoTracker/TkSeedingLayers TrackingTools/TransientTrackingRecHit RecoTracker/TkSeedGenerator CommonTools/Utils DataFormats/Common DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/Math DataFormats/SiPixelDetId DataFormats/TrackerCommon DataFormats/TrackerRecHit2D FWCore/MessageLogger FWCore/Utilities RecoTracker/PixelTrackFitting RecoTracker/TkDetLayers RecoTracker/TkMSParametrization RecoTracker/TkTrackingRegions TrackingTools/DetLayers vdt_headers ofast-flag,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerPixelSeeding_LCGDICTS  := x 
RecoTrackerPixelSeeding_EX_LIB   := RecoTrackerPixelSeeding
ALL_EXTERNAL_PRODS += RecoTrackerPixelSeeding
RecoTrackerPixelSeeding_CLASS := LIBRARY
RecoTracker/PixelSeeding_relbigobj+=RecoTrackerPixelSeeding
endif
ifeq ($(strip $(RecoTrackerPixelSeedingPlugins)),)
RecoTrackerPixelSeedingPlugins := self/src/RecoTracker/PixelSeeding/plugins
RecoTrackerPixelSeedingPlugins_LOC_USE := self cmssw  ofast-flag CommonTools/RecoAlgos FWCore/Framework FWCore/ParameterSet FWCore/PluginManager RecoTracker/PixelSeeding RecoTracker/Record RecoTracker/TkTrackingRegions RecoTracker/TkSeedingLayers cuda HeterogeneousCore/CUDACore CUDADataFormats/Track CUDADataFormats/TrackingRecHit
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerPixelSeedingPlugins
RecoTracker/PixelSeeding_relbigobj+=RecoTrackerPixelSeedingPlugins
endif
ifeq ($(strip $(RecoTrackerPixelSeedingPortable)),)
RecoTrackerPixelSeedingPortable := self/src/RecoTracker/PixelSeeding/plugins
RecoTrackerPixelSeedingPortableCudaAsync_LOC_USE := self cmssw  ofast-flag CommonTools/RecoAlgos FWCore/Framework FWCore/ParameterSet FWCore/PluginManager RecoTracker/PixelSeeding RecoTracker/Record RecoTracker/TkTrackingRegions RecoTracker/TkSeedingLayers cuda alpaka DataFormats/Portable DataFormats/TrackSoA DataFormats/TrackingRecHitSoA FWCore/Utilities HeterogeneousCore/AlpakaCore HeterogeneousCore/AlpakaInterface RecoLocalTracker/Records RecoLocalTracker/SiPixelRecHits
RecoTrackerPixelSeedingPortableCudaAsync_LOC_USE   += alpaka-cuda
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerPixelSeedingPortableCudaAsync
RecoTracker/PixelSeeding_relbigobj+=RecoTrackerPixelSeedingPortableCudaAsync
RecoTrackerPixelSeedingPortableROCmAsync_LOC_USE := self cmssw  ofast-flag CommonTools/RecoAlgos FWCore/Framework FWCore/ParameterSet FWCore/PluginManager RecoTracker/PixelSeeding RecoTracker/Record RecoTracker/TkTrackingRegions RecoTracker/TkSeedingLayers cuda alpaka DataFormats/Portable DataFormats/TrackSoA DataFormats/TrackingRecHitSoA FWCore/Utilities HeterogeneousCore/AlpakaCore HeterogeneousCore/AlpakaInterface RecoLocalTracker/Records RecoLocalTracker/SiPixelRecHits
RecoTrackerPixelSeedingPortableROCmAsync_LOC_USE   += alpaka-rocm
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerPixelSeedingPortableROCmAsync
RecoTracker/PixelSeeding_relbigobj+=RecoTrackerPixelSeedingPortableROCmAsync
RecoTrackerPixelSeedingPortableSerialSync_LOC_USE := self cmssw  ofast-flag CommonTools/RecoAlgos FWCore/Framework FWCore/ParameterSet FWCore/PluginManager RecoTracker/PixelSeeding RecoTracker/Record RecoTracker/TkTrackingRegions RecoTracker/TkSeedingLayers cuda alpaka DataFormats/Portable DataFormats/TrackSoA DataFormats/TrackingRecHitSoA FWCore/Utilities HeterogeneousCore/AlpakaCore HeterogeneousCore/AlpakaInterface RecoLocalTracker/Records RecoLocalTracker/SiPixelRecHits
RecoTrackerPixelSeedingPortableSerialSync_LOC_USE   += alpaka-serial
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerPixelSeedingPortableSerialSync
RecoTracker/PixelSeeding_relbigobj+=RecoTrackerPixelSeedingPortableSerialSync
endif
ifeq ($(strip $(RecoTracker/PixelTrackFitting)),)
RecoTrackerPixelTrackFitting := self/RecoTracker/PixelTrackFitting
RecoTracker/PixelTrackFitting := RecoTrackerPixelTrackFitting
RecoTrackerPixelTrackFitting_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerPixelTrackFitting_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoTrackerPixelTrackFitting_EX_USE := $(foreach d, self cmssw  alpaka cuda eigen root CommonTools/Statistics CommonTools/Utils DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/SiPixelDetId DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrackReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities HeterogeneousCore/AlpakaInterface Geometry/TrackerGeometryBuilder MagneticField/Engine RecoTracker/TkHitPairs RecoTracker/TkMSParametrization RecoTracker/TkTrackingRegions TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/PatternTools TrackingTools/TrajectoryParametrization TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit DataFormats/BeamSpot DataFormats/Common DataFormats/GeometryCommonDetAlgo DataFormats/TrackerCommon RecoTracker/TkSeedingLayers TrackingTools/TrajectoryFiltering,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerPixelTrackFitting_LCGDICTS  := x 
RecoTrackerPixelTrackFitting_EX_LIB   := RecoTrackerPixelTrackFitting
ALL_EXTERNAL_PRODS += RecoTrackerPixelTrackFitting
RecoTrackerPixelTrackFitting_CLASS := LIBRARY
RecoTracker/PixelTrackFitting_relbigobj+=RecoTrackerPixelTrackFitting
endif
ifeq ($(strip $(RecoPixelVertexingPixelTrackFittingPlugins)),)
RecoPixelVertexingPixelTrackFittingPlugins := self/src/RecoTracker/PixelTrackFitting/plugins
RecoPixelVertexingPixelTrackFittingPlugins_LOC_USE := self cmssw  cuda CUDADataFormats/Track DataFormats/TrackSoA DataFormats/TrackingRecHit Geometry/Records RecoTracker/PixelTrackFitting HeterogeneousCore/CUDACore
ALL_EXTERNAL_PLUGIN_PRODS += RecoPixelVertexingPixelTrackFittingPlugins
RecoTracker/PixelTrackFitting_relbigobj+=RecoPixelVertexingPixelTrackFittingPlugins
endif
ifeq ($(strip $(RecoTracker/TkSeedGenerator)),)
RecoTrackerTkSeedGenerator := self/RecoTracker/TkSeedGenerator
RecoTracker/TkSeedGenerator := RecoTrackerTkSeedGenerator
RecoTrackerTkSeedGenerator_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerTkSeedGenerator_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoTrackerTkSeedGenerator_EX_USE := $(foreach d, self cmssw  root eigen FWCore/Framework FWCore/PluginManager DataFormats/Common FWCore/ParameterSet Geometry/Records DataFormats/TrajectorySeed DataFormats/TrackerRecHit2D Geometry/TrackerGeometryBuilder MagneticField/Records MagneticField/Engine TrackingTools/MaterialEffects TrackingTools/Records CommonTools/Utils RecoTracker/TkHitPairs DataFormats/GeometryCommonDetAlgo DataFormats/GeometryVector DataFormats/Math DataFormats/SiPixelCluster DataFormats/SiStripCluster DataFormats/TrackReco DataFormats/TrackingRecHit FWCore/MessageLogger FWCore/Utilities RecoTracker/TkSeedingLayers RecoTracker/TkTrackingRegions TrackingTools/TrajectoryParametrization TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerTkSeedGenerator_LCGDICTS  := x 
RecoTrackerTkSeedGenerator_EX_LIB   := RecoTrackerTkSeedGenerator
ALL_EXTERNAL_PRODS += RecoTrackerTkSeedGenerator
RecoTrackerTkSeedGenerator_CLASS := LIBRARY
RecoTracker/TkSeedGenerator_relbigobj+=RecoTrackerTkSeedGenerator
endif
ifeq ($(strip $(RecoTrackerTkSeedGeneratorPlugins)),)
RecoTrackerTkSeedGeneratorPlugins := self/src/RecoTracker/TkSeedGenerator/plugins
RecoTrackerTkSeedGeneratorPlugins_LOC_USE := self cmssw  cuda CommonTools/RecoAlgos CommonTools/Utils DataFormats/BeamSpot DataFormats/Common DataFormats/L1TrackTrigger DataFormats/Math DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/TrackReco DataFormats/TrackerCommon DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrajectorySeed DataFormats/TrajectoryState DataFormats/VertexReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager FWCore/Utilities Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Engine MagneticField/Records PhysicsTools/TensorFlow RecoTracker/PixelLowPtUtilities RecoTracker/PixelTrackFitting RecoTracker/PixelSeeding RecoTracker/MeasurementDet RecoTracker/Record RecoTracker/TkHitPairs RecoTracker/TkSeedGenerator RecoTracker/TkSeedingLayers RecoTracker/TkTrackingRegions RecoTracker/TransientTrackingRecHit TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/MeasurementDet TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerTkSeedGeneratorPlugins
RecoTracker/TkSeedGenerator_relbigobj+=RecoTrackerTkSeedGeneratorPlugins
endif
ifeq ($(strip $(GammaConversionTrackingForConversionPlugins)),)
GammaConversionTrackingForConversionPlugins := self/src/RecoTracker/ConversionSeedGenerators/plugins
GammaConversionTrackingForConversionPlugins_LOC_USE := self cmssw  root FWCore/Framework DataFormats/Common FWCore/ParameterSet Geometry/Records DataFormats/TrajectorySeed Geometry/TrackerGeometryBuilder DataFormats/SiStripDetId TrackingTools/PatternTools MagneticField/Records MagneticField/Engine TrackingTools/KalmanUpdators TrackingTools/Records RecoTracker/TransientTrackingRecHit RecoTracker/TkSeedGenerator RecoTracker/TkSeedingLayers TrackingTools/TransientTrackingRecHit RecoTracker/TkMSParametrization TrackingTools/DetLayers RecoTracker/TkHitPairs RecoTracker/TkTrackingRegions
ALL_EXTERNAL_PLUGIN_PRODS += GammaConversionTrackingForConversionPlugins
RecoTracker/ConversionSeedGenerators_relbigobj+=GammaConversionTrackingForConversionPlugins
endif
ifeq ($(strip $(RecoTracker/SpecialSeedGenerators)),)
RecoTrackerSpecialSeedGenerators := self/RecoTracker/SpecialSeedGenerators
RecoTracker/SpecialSeedGenerators := RecoTrackerSpecialSeedGenerators
RecoTrackerSpecialSeedGenerators_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerSpecialSeedGenerators_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoTrackerSpecialSeedGenerators_EX_USE := $(foreach d, self cmssw  DataFormats/Common DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/RecoCandidate DataFormats/SiStripDetId DataFormats/TrackerCommon DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet Geometry/TrackerGeometryBuilder MagneticField/Engine RecoTracker/PixelSeeding RecoTracker/Record RecoTracker/TkHitPairs RecoTracker/TkSeedGenerator RecoTracker/TkSeedingLayers RecoTracker/TkTrackingRegions RecoTracker/TransientTrackingRecHit TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/Records TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit TrackingTools/MaterialEffects CommonTools/Utils DataFormats/MuonReco TrackingTools/PatternTools TrackingTools/TrackRefitter,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoTrackerSpecialSeedGenerators
RecoTrackerSpecialSeedGenerators_CLASS := LIBRARY
RecoTracker/SpecialSeedGenerators_relbigobj+=RecoTrackerSpecialSeedGenerators
endif
ifeq ($(strip $(RecoTracker/TkHitPairs)),)
RecoTrackerTkHitPairs := self/RecoTracker/TkHitPairs
RecoTracker/TkHitPairs := RecoTrackerTkHitPairs
RecoTrackerTkHitPairs_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerTkHitPairs_EX_USE := $(foreach d, self cmssw  ofast-flag clhep boost root RecoTracker/Record RecoTracker/TkDetLayers FWCore/ParameterSet TrackingTools/DetLayers DataFormats/TrackerRecHit2D FWCore/Framework TrackingTools/TransientTrackingRecHit RecoTracker/TkMSParametrization RecoTracker/TkSeedingLayers DataFormats/Common DataFormats/GeometryVector DataFormats/Math DataFormats/TrackerCommon DataFormats/TrackingRecHit FWCore/MessageLogger FWCore/Utilities Geometry/Records Geometry/TrackerGeometryBuilder RecoTracker/TkTrackingRegions RecoTracker/TransientTrackingRecHit TrackingTools/Records,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerTkHitPairs_LCGDICTS  := x 
RecoTrackerTkHitPairs_EX_LIB   := RecoTrackerTkHitPairs
ALL_EXTERNAL_PRODS += RecoTrackerTkHitPairs
RecoTrackerTkHitPairs_CLASS := LIBRARY
RecoTracker/TkHitPairs_relbigobj+=RecoTrackerTkHitPairs
endif
ifeq ($(strip $(RecoTrackerTkHitPairsPlugins)),)
RecoTrackerTkHitPairsPlugins := self/src/RecoTracker/TkHitPairs/plugins
RecoTrackerTkHitPairsPlugins_LOC_USE := self cmssw  RecoTracker/TkHitPairs RecoTracker/TkTrackingRegions
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerTkHitPairsPlugins
RecoTracker/TkHitPairs_relbigobj+=RecoTrackerTkHitPairsPlugins
endif
ifeq ($(strip $(RecoTracker/TrackProducer)),)
RecoTrackerTrackProducer := self/RecoTracker/TrackProducer
RecoTracker/TrackProducer := RecoTrackerTrackProducer
RecoTrackerTrackProducer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTrackerTrackProducer_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoTrackerTrackProducer_EX_USE := $(foreach d, self cmssw  TrackingTools/GsfTools DataFormats/Common DataFormats/GsfTrackReco DataFormats/SiStripDetId DataFormats/TrackReco DataFormats/TrackingRecHit DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Engine MagneticField/Records RecoTracker/MeasurementDet TrackingTools/GeomPropagators TrackingTools/PatternTools TrackingTools/Records RecoTracker/SiTrackerMRHTools RecoTracker/TransientTrackingRecHit TrackingTools/TrackFitters TrackingTools/TrajectoryState TrackingTools/KalmanUpdators,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTrackerTrackProducer_EX_LIB   := RecoTrackerTrackProducer
ALL_EXTERNAL_PRODS += RecoTrackerTrackProducer
RecoTrackerTrackProducer_CLASS := LIBRARY
RecoTracker/TrackProducer_relbigobj+=RecoTrackerTrackProducer
endif
ifeq ($(strip $(RecoTrackerTrackProducerPlugins)),)
RecoTrackerTrackProducerPlugins := self/src/RecoTracker/TrackProducer/plugins
RecoTrackerTrackProducerPlugins_LOC_USE := self cmssw  RecoTracker/Record RecoTracker/SiTrackerMRHTools RecoTracker/TrackProducer TrackingTools/TransientTrack FWCore/Utilities Alignment/TwoBodyDecay Alignment/ReferenceTrajectories TrackingTools/GsfTracking
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerTrackProducerPlugins
RecoTracker/TrackProducer_relbigobj+=RecoTrackerTrackProducerPlugins
endif
ifeq ($(strip $(RecoTrackerDebugToolsPlugins)),)
RecoTrackerDebugToolsPlugins := self/src/RecoTracker/DebugTools/plugins
RecoTrackerDebugToolsPlugins_LOC_USE := self cmssw  RecoTracker/CkfPattern SimTracker/TrackerHitAssociation MagneticField/Engine MagneticField/Records TrackingTools/TrajectoryState TrackingTools/PatternTools AnalysisDataFormats/TrackInfo RecoTracker/MeasurementDet
ALL_EXTERNAL_PLUGIN_PRODS += RecoTrackerDebugToolsPlugins
RecoTracker/DebugTools_relbigobj+=RecoTrackerDebugToolsPlugins
endif
ifeq ($(strip $(FastSimulationMuonsPlugins)),)
FastSimulationMuonsPlugins := self/src/FastSimulation/Muons/plugins
FastSimulationMuonsPlugins_LOC_USE := self cmssw  DataFormats/Math DataFormats/MuonSeed DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry FWCore/Utilities FastSimulation/Tracking RecoMuon/GlobalTrackingTools RecoMuon/TrackerSeedGenerator RecoMuon/TrackingTools RecoTracker/TkTrackingRegions SimDataFormats/Track TrackingTools/PatternTools
ALL_EXTERNAL_PLUGIN_PRODS += FastSimulationMuonsPlugins
FastSimulation/Muons_relbigobj+=FastSimulationMuonsPlugins
endif
ifeq ($(strip $(FastSimulation/Tracking)),)
FastSimulationTracking := self/FastSimulation/Tracking
FastSimulation/Tracking := FastSimulationTracking
FastSimulationTracking_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
FastSimulationTracking_EX_USE := $(foreach d, self cmssw  DataFormats/TrajectoryState TrackingTools/GeomPropagators SimDataFormats/Track DataFormats/GeometryVector DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/TrackerCommon DataFormats/TrackingRecHit DataFormats/TrackerRecHit2D Geometry/CommonDetUnit Geometry/TrackerGeometryBuilder RecoTracker/TkHitPairs RecoTracker/PixelSeeding RecoTracker/MeasurementDet,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
FastSimulationTracking_EX_LIB   := FastSimulationTracking
ALL_EXTERNAL_PRODS += FastSimulationTracking
FastSimulationTracking_CLASS := LIBRARY
FastSimulation/Tracking_relbigobj+=FastSimulationTracking
endif
ifeq ($(strip $(FastSimulationTrackingPlugins)),)
FastSimulationTrackingPlugins := self/src/FastSimulation/Tracking/plugins
FastSimulationTrackingPlugins_LOC_USE := self cmssw  DataFormats/Common DataFormats/EgammaReco DataFormats/TrackCandidate DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrajectorySeed FWCore/Framework FWCore/ParameterSet FastSimulation/Tracking Geometry/Records Geometry/TrackerGeometryBuilder RecoTracker/PixelTrackFitting RecoTracker/TkTrackingRegions RecoTracker/TkSeedGenerator SimDataFormats/Track TrackingTools/PatternTools TrackingTools/TrajectoryState SimGeneral/MixingModule
ALL_EXTERNAL_PLUGIN_PRODS += FastSimulationTrackingPlugins
FastSimulation/Tracking_relbigobj+=FastSimulationTrackingPlugins
endif
ifeq ($(strip $(Geometry/HcalTowerAlgo)),)
GeometryHcalTowerAlgo := self/Geometry/HcalTowerAlgo
Geometry/HcalTowerAlgo := GeometryHcalTowerAlgo
GeometryHcalTowerAlgo_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
GeometryHcalTowerAlgo_EX_USE := $(foreach d, self cmssw  Geometry/CaloGeometry Geometry/CaloTopology Geometry/HcalCommonData DataFormats/HcalDetId DataFormats/CaloTowers FWCore/MessageLogger FWCore/ParameterSet clhep boost_serialization,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
GeometryHcalTowerAlgo_EX_LIB   := GeometryHcalTowerAlgo
ALL_EXTERNAL_PRODS += GeometryHcalTowerAlgo
GeometryHcalTowerAlgo_CLASS := LIBRARY
Geometry/HcalTowerAlgo_relbigobj+=GeometryHcalTowerAlgo
endif
ifeq ($(strip $(GeometryHcalTowerAlgoPlugins)),)
GeometryHcalTowerAlgoPlugins := self/src/Geometry/HcalTowerAlgo/plugins
GeometryHcalTowerAlgoPlugins_LOC_USE := self cmssw  FWCore/Framework Geometry/Records Geometry/HcalTowerAlgo
ALL_EXTERNAL_PLUGIN_PRODS += GeometryHcalTowerAlgoPlugins
Geometry/HcalTowerAlgo_relbigobj+=GeometryHcalTowerAlgoPlugins
endif
ifeq ($(strip $(Geometry/HGCalGeometry)),)
GeometryHGCalGeometry := self/Geometry/HGCalGeometry
Geometry/HGCalGeometry := GeometryHGCalGeometry
GeometryHGCalGeometry_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
GeometryHGCalGeometry_EX_USE := $(foreach d, self cmssw  DataFormats/ForwardDetId DataFormats/Common Geometry/CaloGeometry Geometry/CaloTopology Geometry/HGCalCommonData MagneticField/Engine TrackingTools/TrajectoryState TrackingTools/GeomPropagators,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
GeometryHGCalGeometry_EX_LIB   := GeometryHGCalGeometry
ALL_EXTERNAL_PRODS += GeometryHGCalGeometry
GeometryHGCalGeometry_CLASS := LIBRARY
Geometry/HGCalGeometry_relbigobj+=GeometryHGCalGeometry
endif
ifeq ($(strip $(GeometryHGCalGeometryPlugins)),)
GeometryHGCalGeometryPlugins := self/src/Geometry/HGCalGeometry/plugins
GeometryHGCalGeometryPlugins_LOC_USE := self cmssw  FWCore/Framework FWCore/ParameterSet Geometry/HGCalGeometry Geometry/CaloTopology Geometry/Records
ALL_EXTERNAL_PLUGIN_PRODS += GeometryHGCalGeometryPlugins
Geometry/HGCalGeometry_relbigobj+=GeometryHGCalGeometryPlugins
endif
ifeq ($(strip $(HLTriggerbtauAuto)),)
HLTriggerbtauAuto := self/src/HLTrigger/btau/plugins
HLTriggerbtauAuto_LOC_USE := self cmssw  DataFormats/BTauReco DataFormats/Candidate DataFormats/Common DataFormats/HLTReco DataFormats/JetReco DataFormats/RecoCandidate DataFormats/TrackReco DataFormats/VertexReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities HLTrigger/HLTcore RecoTracker/TkTrackingRegions RecoVertex/KalmanVertexFit RecoVertex/VertexPrimitives TrackingTools/Records TrackingTools/TransientTrack
ALL_EXTERNAL_PLUGIN_PRODS += HLTriggerbtauAuto
HLTrigger/btau_relbigobj+=HLTriggerbtauAuto
endif
ifeq ($(strip $(RecoHIHiMuonAlgosPlugins)),)
RecoHIHiMuonAlgosPlugins := self/src/RecoHI/HiMuonAlgos/plugins
RecoHIHiMuonAlgosPlugins_LOC_USE := self cmssw  boost FWCore/Framework FWCore/PluginManager FWCore/ParameterSet RecoMuon/GlobalTrackingTools hepmc
ALL_EXTERNAL_PLUGIN_PRODS += RecoHIHiMuonAlgosPlugins
RecoHI/HiMuonAlgos_relbigobj+=RecoHIHiMuonAlgosPlugins
endif
ifeq ($(strip $(RecoHI/HiTracking)),)
RecoHIHiTracking := self/RecoHI/HiTracking
RecoHI/HiTracking := RecoHIHiTracking
RecoHIHiTracking_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoHIHiTracking_EX_USE := $(foreach d, self cmssw  DataFormats/BeamSpot DataFormats/CaloTowers DataFormats/Math DataFormats/ParticleFlowReco DataFormats/ParticleFlowCandidate DataFormats/TrackReco DataFormats/VertexReco FWCore/Framework FWCore/ParameterSet FWCore/PluginManager TrackingTools/PatternTools RecoTracker/PixelTrackFitting RecoTracker/PixelLowPtUtilities SimDataFormats/TrackingAnalysis,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoHIHiTracking_EX_LIB   := RecoHIHiTracking
ALL_EXTERNAL_PRODS += RecoHIHiTracking
RecoHIHiTracking_CLASS := LIBRARY
RecoHI/HiTracking_relbigobj+=RecoHIHiTracking
endif
ifeq ($(strip $(RecoHIHiTrackingPlugins)),)
RecoHIHiTrackingPlugins := self/src/RecoHI/HiTracking/plugins
RecoHIHiTrackingPlugins_LOC_USE := self cmssw  CommonTools/UtilAlgos CommonTools/Utils CondFormats/GBRForest DataFormats/BeamSpot DataFormats/Common DataFormats/GeometryVector DataFormats/SiPixelCluster DataFormats/TrackReco DataFormats/TrackerCommon DataFormats/TrackerRecHit2D DataFormats/VertexReco CondFormats/DataRecord FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager FWCore/Utilities Geometry/CommonTopologies Geometry/Records Geometry/TrackerGeometryBuilder RecoTracker/PixelTrackFitting RecoTracker/TkTrackingRegions RecoHI/HiTracking SimDataFormats/Vertex TrackingTools/PatternTools rootminuit
ALL_EXTERNAL_PLUGIN_PRODS += RecoHIHiTrackingPlugins
RecoHI/HiTracking_relbigobj+=RecoHIHiTrackingPlugins
endif
ifeq ($(strip $(RecoTauTag/HLTProducers)),)
RecoTauTagHLTProducers := self/RecoTauTag/HLTProducers
RecoTauTag/HLTProducers := RecoTauTagHLTProducers
RecoTauTagHLTProducers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTauTagHLTProducers_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/ParameterSet DataFormats/Common DataFormats/BTauReco DataFormats/TauReco DataFormats/TrackReco DataFormats/Math DataFormats/Candidate DataFormats/JetReco DataFormats/CaloTowers DataFormats/VertexReco DataFormats/L1Trigger DataFormats/HLTReco HLTrigger/HLTcore RecoTracker/TkTrackingRegions CUDADataFormats/SiPixelCluster CUDADataFormats/Track CUDADataFormats/Vertex PhysicsTools/TensorFlow root,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoTauTagHLTProducers
RecoTauTagHLTProducers_CLASS := LIBRARY
RecoTauTag/HLTProducers_relbigobj+=RecoTauTagHLTProducers
endif
ifeq ($(strip $(RecoTauTag/RecoTau)),)
RecoTauTagRecoTau := self/RecoTauTag/RecoTau
RecoTauTag/RecoTau := RecoTauTagRecoTau
RecoTauTagRecoTau_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoTauTagRecoTau_EX_USE := $(foreach d, self cmssw  MagneticField/Engine MagneticField/Records Geometry/CaloTopology Geometry/CaloGeometry CondFormats/GBRForest CondFormats/DataRecord CondFormats/EcalObjects DataFormats/Math DataFormats/TauReco DataFormats/VertexReco DataFormats/PatCandidates DataFormats/ParticleFlowCandidate DataFormats/TrackReco DataFormats/DetId DataFormats/EcalDetId FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager TrackingTools/TransientTrack TrackingTools/Records RecoVertex/AdaptiveVertexFit PhysicsTools/JetMCUtils CommonTools/Utils CommonTools/BaseParticlePropagator RecoLocalCalo/HGCalRecAlgos roottmva PhysicsTools/TensorFlow,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoTauTagRecoTau_EX_LIB   := RecoTauTagRecoTau
ALL_EXTERNAL_PRODS += RecoTauTagRecoTau
RecoTauTagRecoTau_CLASS := LIBRARY
RecoTauTag/RecoTau_relbigobj+=RecoTauTagRecoTau
endif
ifeq ($(strip $(RecoTauTagRecoTauPlugins)),)
RecoTauTagRecoTauPlugins := self/src/RecoTauTag/RecoTau/plugins
RecoTauTagRecoTauPlugins_LOC_USE := self cmssw  root tbb CommonTools/BaseParticlePropagator CommonTools/CandUtils CommonTools/UtilAlgos CondFormats/DataRecord CondFormats/GBRForest DataFormats/Candidate DataFormats/JetReco DataFormats/MuonReco DataFormats/ParticleFlowReco DataFormats/TauReco DataFormats/TrackReco DataFormats/VertexReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities Geometry/CaloGeometry Geometry/HcalTowerAlgo Geometry/Records HeterogeneousCore/SonicTriton MagneticField/Engine MagneticField/Records PhysicsTools/TensorFlow RecoBTag/SecondaryVertex RecoTauTag/RecoTau RecoVertex/KalmanVertexFit RecoVertex/VertexPrimitives TrackingTools/IPTools TrackingTools/Records TrackingTools/TransientTrack
ALL_EXTERNAL_PLUGIN_PRODS += RecoTauTagRecoTauPlugins
RecoTauTag/RecoTau_relbigobj+=RecoTauTagRecoTauPlugins
endif
ifeq ($(strip $(SimTracker/TrackHistory)),)
SimTrackerTrackHistory := self/SimTracker/TrackHistory
SimTracker/TrackHistory := SimTrackerTrackHistory
SimTrackerTrackHistory_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
SimTrackerTrackHistory_EX_USE := $(foreach d, self cmssw  clhep boost root DataFormats/Math DataFormats/VertexReco DataFormats/JetReco FWCore/Framework FWCore/ParameterSet FWCore/Utilities MagneticField/Records MagneticField/Engine SimDataFormats/TrackingAnalysis SimGeneral/HepPDTRecord SimTracker/TrackerHitAssociation TrackingTools/TransientTrack DataFormats/TrackerCommon CommonTools/Utils DataFormats/BeamSpot DataFormats/Common DataFormats/DetId DataFormats/MuonDetId DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/TrackReco DataFormats/TrackingRecHit FWCore/MessageLogger Geometry/Records SimDataFormats/Associations SimDataFormats/TrackingHit TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryState,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
SimTrackerTrackHistory_LCGDICTS  := x 
SimTrackerTrackHistory_EX_LIB   := SimTrackerTrackHistory
ALL_EXTERNAL_PRODS += SimTrackerTrackHistory
SimTrackerTrackHistory_CLASS := LIBRARY
SimTracker/TrackHistory_relbigobj+=SimTrackerTrackHistory
endif
ifeq ($(strip $(TrackHistoryPlugins)),)
TrackHistoryPlugins := self/src/SimTracker/TrackHistory/plugins
TrackHistoryPlugins_LOC_USE := self cmssw  root TrackingTools/IPTools SimTracker/TrackHistory DataFormats/BTauReco RecoVertex/PrimaryVertexProducer CommonTools/UtilAlgos
ALL_EXTERNAL_PLUGIN_PRODS += TrackHistoryPlugins
SimTracker/TrackHistory_relbigobj+=TrackHistoryPlugins
endif
ifeq ($(strip $(CmsHiValidationPlugins)),)
CmsHiValidationPlugins := self/src/Validation/RecoHI/plugins
CmsHiValidationPlugins_LOC_USE := self cmssw  hepmc SimDataFormats/GeneratorProducts DQMServices/Core SimGeneral/HepPDTRecord SimDataFormats/TrackingAnalysis DataFormats/TrackerCommon Geometry/Records
ALL_EXTERNAL_PLUGIN_PRODS += CmsHiValidationPlugins
Validation/RecoHI_relbigobj+=CmsHiValidationPlugins
endif
ifeq ($(strip $(Validation/RecoParticleFlow)),)
ValidationRecoParticleFlow := self/Validation/RecoParticleFlow
Validation/RecoParticleFlow := ValidationRecoParticleFlow
ValidationRecoParticleFlow_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
ValidationRecoParticleFlow_EX_USE := $(foreach d, self cmssw  root rootgpad rootcore,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ValidationRecoParticleFlow_LCGDICTS  := x 
ValidationRecoParticleFlow_EX_LIB   := ValidationRecoParticleFlow
ALL_EXTERNAL_PRODS += ValidationRecoParticleFlow
ValidationRecoParticleFlow_CLASS := LIBRARY
Validation/RecoParticleFlow_relbigobj+=ValidationRecoParticleFlow
endif
ifeq ($(strip $(ValidationRecoParticleFlow_plugins)),)
ValidationRecoParticleFlow_plugins := self/src/Validation/RecoParticleFlow/plugins
ValidationRecoParticleFlow_plugins_LOC_USE := self cmssw  FWCore/Framework root rootcore FWCore/MessageLogger FWCore/ParameterSet DQMServices/Core DataFormats/METReco DataFormats/PatCandidates DataFormats/ParticleFlowReco DataFormats/ParticleFlowCandidate RecoParticleFlow/Benchmark CommonTools/UtilAlgos Geometry/HcalTowerAlgo MagneticField/Records
ALL_EXTERNAL_PLUGIN_PRODS += ValidationRecoParticleFlow_plugins
Validation/RecoParticleFlow_relbigobj+=ValidationRecoParticleFlow_plugins
endif
ifeq ($(strip $(Validation/RecoTau)),)
ValidationRecoTau := self/Validation/RecoTau
Validation/RecoTau := ValidationRecoTau
ValidationRecoTau_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
ValidationRecoTau_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/MessageLogger FWCore/PluginManager FWCore/ParameterSet DataFormats/TauReco DataFormats/PatCandidates DQMServices/Core PhysicsTools/JetMCUtils CommonTools/Utils CommonTools/TriggerUtils,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += ValidationRecoTau
ValidationRecoTau_CLASS := LIBRARY
Validation/RecoTau_relbigobj+=ValidationRecoTau
endif
ifeq ($(strip $(ValidationRecoTauPlugin)),)
ValidationRecoTauPlugin := self/src/Validation/RecoTau/plugins
ValidationRecoTauPlugin_LOC_USE := self cmssw  FWCore/Framework FWCore/PluginManager classlib FWCore/ParameterSet DQMServices/Core rootgraphics DataFormats/TauReco DataFormats/MuonReco DataFormats/JetReco DataFormats/EgammaCandidates DataFormats/HepMCCandidate CommonTools/UtilAlgos
ALL_EXTERNAL_PLUGIN_PRODS += ValidationRecoTauPlugin
Validation/RecoTau_relbigobj+=ValidationRecoTauPlugin
endif
ifeq ($(strip $(Validation/RecoTrack)),)
ValidationRecoTrack := self/Validation/RecoTrack
Validation/RecoTrack := ValidationRecoTrack
ValidationRecoTrack_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
ValidationRecoTrack_EX_USE := $(foreach d, self cmssw  DQMServices/Core SimDataFormats/TrackingAnalysis DataFormats/TrackReco root SimTracker/TrackAssociation SimTracker/TrackerHitAssociation DQM/SiStripCommon CalibTracker/Records RecoTracker/TkSeedingLayers,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ValidationRecoTrack_EX_LIB   := ValidationRecoTrack
ALL_EXTERNAL_PRODS += ValidationRecoTrack
ValidationRecoTrack_CLASS := LIBRARY
Validation/RecoTrack_relbigobj+=ValidationRecoTrack
endif
ifeq ($(strip $(ValidationRecoTrackPlugins)),)
ValidationRecoTrackPlugins := self/src/Validation/RecoTrack/plugins
ValidationRecoTrackPlugins_LOC_USE := self cmssw  FWCore/Utilities FWCore/Framework CommonTools/UtilAlgos DataFormats/Common DataFormats/TrackReco clhep SimDataFormats/TrackerDigiSimLink FWCore/ParameterSet Geometry/TrackerGeometryBuilder Geometry/Records MagneticField/Records MagneticField/Engine SimDataFormats/Vertex SimDataFormats/TrackingAnalysis SimDataFormats/PileupSummaryInfo SimDataFormats/EncodedEventId root SimGeneral/TrackingAnalysis SimTracker/TrackAssociation SimTracker/TrackerHitAssociation SimTracker/TrackHistory Validation/RecoTrack RecoTracker/PixelTrackFitting DataFormats/VertexReco DataFormats/Phase2TrackerCluster
ALL_EXTERNAL_PLUGIN_PRODS += ValidationRecoTrackPlugins
Validation/RecoTrack_relbigobj+=ValidationRecoTrackPlugins
endif
ifeq ($(strip $(SimG4Core/CustomPhysics)),)
SimG4CoreCustomPhysics := self/SimG4Core/CustomPhysics
SimG4Core/CustomPhysics := SimG4CoreCustomPhysics
SimG4CoreCustomPhysics_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
SimG4CoreCustomPhysics_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/MessageLogger SimG4Core/Notification SimG4Core/Physics SimG4Core/PhysicsLists SimG4Core/Watcher geant4core clhep boost rootmath root,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
SimG4CoreCustomPhysics_EX_LIB   := SimG4CoreCustomPhysics
ALL_EXTERNAL_PRODS += SimG4CoreCustomPhysics
SimG4CoreCustomPhysics_CLASS := LIBRARY
SimG4Core/CustomPhysics_relbigobj+=SimG4CoreCustomPhysics
endif
ifeq ($(strip $(SimG4CoreCustomPhysicsPlugins)),)
SimG4CoreCustomPhysicsPlugins := self/src/SimG4Core/CustomPhysics/plugins
SimG4CoreCustomPhysicsPlugins_LOC_USE := self cmssw  SimG4Core/Watcher SimG4Core/Notification FWCore/ParameterSet FWCore/PluginManager geant4core clhep boost SimG4Core/CustomPhysics
ALL_EXTERNAL_PLUGIN_PRODS += SimG4CoreCustomPhysicsPlugins
SimG4Core/CustomPhysics_relbigobj+=SimG4CoreCustomPhysicsPlugins
endif
ifeq ($(strip $(L1Trigger/Phase2L1ParticleFlow)),)
L1TriggerPhase2L1ParticleFlow := self/L1Trigger/Phase2L1ParticleFlow
L1Trigger/Phase2L1ParticleFlow := L1TriggerPhase2L1ParticleFlow
L1TriggerPhase2L1ParticleFlow_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
L1TriggerPhase2L1ParticleFlow_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/ParameterSet FWCore/Utilities DataFormats/L1THGCal DataFormats/L1TParticleFlow CommonTools/BaseParticlePropagator DataFormats/ParticleFlowReco CommonTools/Utils CommonTools/MVAUtils L1Trigger/DemonstratorTools PhysicsTools/TensorFlow conifer tensorflow roottmva hls,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
L1TriggerPhase2L1ParticleFlow_EX_LIB   := L1TriggerPhase2L1ParticleFlow
ALL_EXTERNAL_PRODS += L1TriggerPhase2L1ParticleFlow
L1TriggerPhase2L1ParticleFlow_CLASS := LIBRARY
L1Trigger/Phase2L1ParticleFlow_relbigobj+=L1TriggerPhase2L1ParticleFlow
endif
ifeq ($(strip $(L1TriggerPhase2L1ParticleFlowAuto)),)
L1TriggerPhase2L1ParticleFlowAuto := self/src/L1Trigger/Phase2L1ParticleFlow/plugins
L1TriggerPhase2L1ParticleFlowAuto_LOC_USE := self cmssw  CalibFormats/CaloTPG DataFormats/HcalDetId DataFormats/HcalDigi DataFormats/JetReco DataFormats/L1TCorrelator L1Trigger/DemonstratorTools L1Trigger/L1TCalorimeter L1Trigger/Phase2L1ParticleFlow MagneticField/Engine MagneticField/Records CommonTools/Utils CommonTools/UtilAlgos
ALL_EXTERNAL_PLUGIN_PRODS += L1TriggerPhase2L1ParticleFlowAuto
L1Trigger/Phase2L1ParticleFlow_relbigobj+=L1TriggerPhase2L1ParticleFlowAuto
endif
ifeq ($(strip $(L1Trigger/L1CaloTrigger)),)
L1TriggerL1CaloTrigger := self/L1Trigger/L1CaloTrigger
L1Trigger/L1CaloTrigger := L1TriggerL1CaloTrigger
L1TriggerL1CaloTrigger_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
L1TriggerL1CaloTrigger_EX_USE := $(foreach d, self cmssw  DataFormats/EcalDetId DataFormats/HcalDetId DataFormats/L1TCalorimeterPhase2 FWCore/ParameterSet clhep hls,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
L1TriggerL1CaloTrigger_EX_LIB   := L1TriggerL1CaloTrigger
ALL_EXTERNAL_PRODS += L1TriggerL1CaloTrigger
L1TriggerL1CaloTrigger_CLASS := LIBRARY
L1Trigger/L1CaloTrigger_relbigobj+=L1TriggerL1CaloTrigger
endif
ifeq ($(strip $(L1TriggerL1CaloTriggerAuto)),)
L1TriggerL1CaloTriggerAuto := self/src/L1Trigger/L1CaloTrigger/plugins
L1TriggerL1CaloTriggerAuto_LOC_USE := self cmssw  FWCore/Framework Geometry/CaloGeometry Geometry/HcalTowerAlgo Geometry/EcalAlgo DataFormats/L1TCalorimeterPhase2 DataFormats/L1Trigger DataFormats/HcalDetId DataFormats/EcalDigi DataFormats/HcalDigi DataFormats/JetReco CalibFormats/CaloTPG L1Trigger/L1CaloTrigger DataFormats/L1THGCal L1Trigger/L1TCalorimeter FWCore/ParameterSet root boost
ALL_EXTERNAL_PLUGIN_PRODS += L1TriggerL1CaloTriggerAuto
L1Trigger/L1CaloTrigger_relbigobj+=L1TriggerL1CaloTriggerAuto
endif
ifeq ($(strip $(RecoLocalCalo/HGCalRecAlgos)),)
RecoLocalCaloHGCalRecAlgos := self/RecoLocalCalo/HGCalRecAlgos
RecoLocalCalo/HGCalRecAlgos := RecoLocalCaloHGCalRecAlgos
RecoLocalCaloHGCalRecAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoLocalCaloHGCalRecAlgos_EX_USE := $(foreach d, self cmssw  clhep DataFormats/HGCRecHit root rootminuit FWCore/MessageLogger FWCore/ParameterSet FWCore/Framework Geometry/HGCalGeometry Geometry/HcalTowerAlgo Geometry/Records DataFormats/ParticleFlowReco,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoLocalCaloHGCalRecAlgos_EX_LIB   := RecoLocalCaloHGCalRecAlgos
ALL_EXTERNAL_PRODS += RecoLocalCaloHGCalRecAlgos
RecoLocalCaloHGCalRecAlgos_CLASS := LIBRARY
RecoLocalCalo/HGCalRecAlgos_relbigobj+=RecoLocalCaloHGCalRecAlgos
endif
ifeq ($(strip $(RecoLocalCalo/HGCalRecProducers)),)
RecoLocalCaloHGCalRecProducers := self/RecoLocalCalo/HGCalRecProducers
RecoLocalCalo/HGCalRecProducers := RecoLocalCaloHGCalRecProducers
RecoLocalCaloHGCalRecProducers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoLocalCaloHGCalRecProducers_EX_USE := $(foreach d, self cmssw  cuda FWCore/Framework FWCore/ParameterSet DataFormats/HGCRecHit RecoLocalCalo/HGCalRecAlgos Geometry/HGCalGeometry clhep,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoLocalCaloHGCalRecProducers_EX_LIB   := RecoLocalCaloHGCalRecProducers
ALL_EXTERNAL_PRODS += RecoLocalCaloHGCalRecProducers
RecoLocalCaloHGCalRecProducers_CLASS := LIBRARY
RecoLocalCalo/HGCalRecProducers_relbigobj+=RecoLocalCaloHGCalRecProducers
endif
ifeq ($(strip $(RecoLocalCaloHGCalRecProducersPlugins)),)
RecoLocalCaloHGCalRecProducersPlugins := self/src/RecoLocalCalo/HGCalRecProducers/plugins
RecoLocalCaloHGCalRecProducersPlugins_LOC_USE := self cmssw  cuda tbb CommonTools/UtilAlgos CondFormats/DataRecord CondFormats/HGCalObjects DataFormats/ForwardDetId DataFormats/HGCDigi DataFormats/HGCRecHit DataFormats/HcalDetId FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry FWCore/Utilities Geometry/CaloGeometry Geometry/HGCalCommonData Geometry/HGCalGeometry HeterogeneousCore/CUDACore HeterogeneousCore/CUDAUtilities RecoLocalCalo/HGCalRecAlgos RecoLocalCalo/HGCalRecProducers
ALL_EXTERNAL_PLUGIN_PRODS += RecoLocalCaloHGCalRecProducersPlugins
RecoLocalCalo/HGCalRecProducers_relbigobj+=RecoLocalCaloHGCalRecProducersPlugins
endif
ifeq ($(strip $(RecoLocalTracker/SiStripClusterizer)),)
RecoLocalTrackerSiStripClusterizer := self/RecoLocalTracker/SiStripClusterizer
RecoLocalTracker/SiStripClusterizer := RecoLocalTrackerSiStripClusterizer
RecoLocalTrackerSiStripClusterizer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoLocalTrackerSiStripClusterizer_EX_USE := $(foreach d, self cmssw  DataFormats/Common FWCore/Framework FWCore/ParameterSet FWCore/Utilities DataFormats/SiStripDigi DataFormats/SiStripCluster CondFormats/DataRecord CondFormats/SiStripObjects CalibFormats/SiStripObjects CalibTracker/Records RecoLocalTracker/Records,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoLocalTrackerSiStripClusterizer_EX_LIB   := RecoLocalTrackerSiStripClusterizer
ALL_EXTERNAL_PRODS += RecoLocalTrackerSiStripClusterizer
RecoLocalTrackerSiStripClusterizer_CLASS := LIBRARY
RecoLocalTracker/SiStripClusterizer_relbigobj+=RecoLocalTrackerSiStripClusterizer
endif
ifeq ($(strip $(RecoLocalTrackerSiStripClusterizerPlugins)),)
RecoLocalTrackerSiStripClusterizerPlugins := self/src/RecoLocalTracker/SiStripClusterizer/plugins
RecoLocalTrackerSiStripClusterizerPlugins_LOC_USE := self cmssw  EventFilter/SiStripRawToDigi RecoLocalTracker/SiStripClusterizer RecoLocalTracker/SiStripZeroSuppression HeterogeneousCore/CUDACore HeterogeneousCore/CUDAUtilities CUDADataFormats/SiStripCluster cuda RecoTracker/PixelLowPtUtilities CalibFormats/SiStripObjects CalibTracker/SiStripCommon
ALL_EXTERNAL_PLUGIN_PRODS += RecoLocalTrackerSiStripClusterizerPlugins
RecoLocalTracker/SiStripClusterizer_relbigobj+=RecoLocalTrackerSiStripClusterizerPlugins
endif
ifeq ($(strip $(CommonTools/UtilAlgos)),)
CommonToolsUtilAlgos := self/CommonTools/UtilAlgos
CommonTools/UtilAlgos := CommonToolsUtilAlgos
CommonToolsUtilAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CommonToolsUtilAlgos_EX_USE := $(foreach d, self cmssw  CommonTools/Utils FWCore/ServiceRegistry FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities DataFormats/Provenance DataFormats/DetId roothistmatrix,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CommonToolsUtilAlgos_EX_LIB   := CommonToolsUtilAlgos
ALL_EXTERNAL_PRODS += CommonToolsUtilAlgos
CommonToolsUtilAlgos_CLASS := LIBRARY
CommonTools/UtilAlgos_relbigobj+=CommonToolsUtilAlgos
endif
ifeq ($(strip $(CommonToolsToolsUtilAlgos_plugins)),)
CommonToolsToolsUtilAlgos_plugins := self/src/CommonTools/UtilAlgos/plugins
CommonToolsToolsUtilAlgos_plugins_LOC_USE := self cmssw  FWCore/Framework FWCore/ParameterSet CommonTools/UtilAlgos FWCore/ServiceRegistry DataFormats/Candidate
ALL_EXTERNAL_PLUGIN_PRODS += CommonToolsToolsUtilAlgos_plugins
CommonTools/UtilAlgos_relbigobj+=CommonToolsToolsUtilAlgos_plugins
endif
ifeq ($(strip $(CommonTools/ParticleFlow)),)
CommonToolsParticleFlow := self/CommonTools/ParticleFlow
CommonTools/ParticleFlow := CommonToolsParticleFlow
CommonToolsParticleFlow_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CommonToolsParticleFlow_EX_USE := $(foreach d, self cmssw  DataFormats/Common DataFormats/ParticleFlowCandidate DataFormats/EgammaCandidates DataFormats/METReco DataFormats/JetReco DataFormats/PatCandidates rootmath FWCore/ParameterSet,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CommonToolsParticleFlow_EX_LIB   := CommonToolsParticleFlow
ALL_EXTERNAL_PRODS += CommonToolsParticleFlow
CommonToolsParticleFlow_CLASS := LIBRARY
CommonTools/ParticleFlow_relbigobj+=CommonToolsParticleFlow
endif
ifeq ($(strip $(CommonToolsParticleFlow_plugins)),)
CommonToolsParticleFlow_plugins := self/src/CommonTools/ParticleFlow/plugins
CommonToolsParticleFlow_plugins_LOC_USE := self cmssw  DataFormats/ParticleFlowCandidate DataFormats/JetReco DataFormats/TauReco DataFormats/METReco DataFormats/TrackReco DataFormats/VertexReco PhysicsTools/IsolationAlgos FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet CommonTools/Utils CommonTools/ParticleFlow CalibFormats/HcalObjects Geometry/HcalTowerAlgo
ALL_EXTERNAL_PLUGIN_PRODS += CommonToolsParticleFlow_plugins
CommonTools/ParticleFlow_relbigobj+=CommonToolsParticleFlow_plugins
endif
ifeq ($(strip $(CommonTools/CandAlgos)),)
CommonToolsCandAlgos := self/CommonTools/CandAlgos
CommonTools/CandAlgos := CommonToolsCandAlgos
CommonToolsCandAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CommonToolsCandAlgos_EX_USE := $(foreach d, self cmssw  SimGeneral/HepPDTRecord FWCore/Framework FWCore/ParameterSet DataFormats/PatCandidates CommonTools/CandUtils,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CommonToolsCandAlgos_EX_LIB   := CommonToolsCandAlgos
ALL_EXTERNAL_PRODS += CommonToolsCandAlgos
CommonToolsCandAlgos_CLASS := LIBRARY
CommonTools/CandAlgos_relbigobj+=CommonToolsCandAlgos
endif
ifeq ($(strip $(CommonToolsCandAlgos_plugins)),)
CommonToolsCandAlgos_plugins := self/src/CommonTools/CandAlgos/plugins
CommonToolsCandAlgos_plugins_LOC_USE := self cmssw  FWCore/Framework FWCore/ParameterSet DataFormats/Candidate DataFormats/HepMCCandidate CommonTools/UtilAlgos CommonTools/Utils CommonTools/CandAlgos
ALL_EXTERNAL_PLUGIN_PRODS += CommonToolsCandAlgos_plugins
CommonTools/CandAlgos_relbigobj+=CommonToolsCandAlgos_plugins
endif
ifeq ($(strip $(CommonTools/RecoAlgos)),)
CommonToolsRecoAlgos := self/CommonTools/RecoAlgos
CommonTools/RecoAlgos := CommonToolsRecoAlgos
CommonToolsRecoAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CommonToolsRecoAlgos_EX_USE := $(foreach d, self cmssw  SimGeneral/HepPDTRecord FWCore/Framework FWCore/ParameterSet DataFormats/Math DataFormats/TrackReco DataFormats/MuonReco DataFormats/TrackingRecHit DataFormats/SiStripCluster DataFormats/SiPixelCluster DataFormats/Phase2TrackerCluster DataFormats/TrackerRecHit2D DataFormats/RecoCandidate DataFormats/Candidate DataFormats/VertexReco TrackingTools/IPTools TrackingTools/TransientTrack Geometry/TrackerGeometryBuilder SimDataFormats/TrackingAnalysis fastjet,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CommonToolsRecoAlgos_EX_LIB   := CommonToolsRecoAlgos
ALL_EXTERNAL_PRODS += CommonToolsRecoAlgos
CommonToolsRecoAlgos_CLASS := LIBRARY
CommonTools/RecoAlgos_relbigobj+=CommonToolsRecoAlgos
endif
ifeq ($(strip $(CommonToolsRecoAlgos_plugins)),)
CommonToolsRecoAlgos_plugins := self/src/CommonTools/RecoAlgos/plugins
CommonToolsRecoAlgos_plugins_LOC_USE := self cmssw  FWCore/Framework FWCore/ParameterSet DataFormats/RecoCandidate DataFormats/BTauReco DataFormats/EgammaCandidates DataFormats/EgammaReco DataFormats/MuonReco DataFormats/JetReco DataFormats/METReco DataFormats/PatCandidates DataFormats/HcalRecHit SimDataFormats/TrackingAnalysis TrackingTools/Records CommonTools/Utils CommonTools/RecoAlgos
ALL_EXTERNAL_PLUGIN_PRODS += CommonToolsRecoAlgos_plugins
CommonTools/RecoAlgos_relbigobj+=CommonToolsRecoAlgos_plugins
endif
ifeq ($(strip $(GeneratorInterfaceGenFiltersPlugins)),)
GeneratorInterfaceGenFiltersPlugins := self/src/GeneratorInterface/GenFilters/plugins
GeneratorInterfaceGenFiltersPlugins_LOC_USE := self cmssw  FWCore/ParameterSet FWCore/Framework FWCore/Utilities SimDataFormats/GeneratorProducts GeneratorInterface/Core SimGeneral/HepPDTRecord DataFormats/GeometryVector DataFormats/GeometrySurface TrackPropagation/SteppingHelixPropagator MagneticField/Records TrackingTools/TrajectoryState TrackingTools/TrajectoryParametrization TrackingTools/Records CommonTools/UtilAlgos FWCore/ServiceRegistry TrackingTools/GeomPropagators DataFormats/HepMCCandidate DataFormats/JetReco DataFormats/Math SimDataFormats/HTXS fastjet boost heppdt clhep rootcore pythia6 pythia8
ALL_EXTERNAL_PLUGIN_PRODS += GeneratorInterfaceGenFiltersPlugins
GeneratorInterface/GenFilters_relbigobj+=GeneratorInterfaceGenFiltersPlugins
endif
ifeq ($(strip $(GeneratorInterface/CosmicMuonGenerator)),)
GeneratorInterfaceCosmicMuonGenerator := self/GeneratorInterface/CosmicMuonGenerator
GeneratorInterface/CosmicMuonGenerator := GeneratorInterfaceCosmicMuonGenerator
GeneratorInterfaceCosmicMuonGenerator_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
GeneratorInterfaceCosmicMuonGenerator_EX_USE := $(foreach d, self cmssw  boost FWCore/Framework FWCore/ServiceRegistry SimDataFormats/GeneratorProducts clhep root hepmc,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += GeneratorInterfaceCosmicMuonGenerator
GeneratorInterfaceCosmicMuonGenerator_CLASS := LIBRARY
GeneratorInterface/CosmicMuonGenerator_relbigobj+=GeneratorInterfaceCosmicMuonGenerator
endif
ifeq ($(strip $(Alignment/HIPAlignmentAlgorithm)),)
AlignmentHIPAlignmentAlgorithm := self/Alignment/HIPAlignmentAlgorithm
Alignment/HIPAlignmentAlgorithm := AlignmentHIPAlignmentAlgorithm
AlignmentHIPAlignmentAlgorithm_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
AlignmentHIPAlignmentAlgorithm_EX_USE := $(foreach d, self cmssw  FWCore/MessageLogger FWCore/ParameterSet CondFormats/Alignment TrackingTools/PatternTools TrackingTools/TrackFitters DataFormats/Alignment Alignment/CommonAlignment Alignment/CommonAlignmentAlgorithm Alignment/TrackerAlignment Utilities/General rootcore,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += AlignmentHIPAlignmentAlgorithm
AlignmentHIPAlignmentAlgorithm_CLASS := LIBRARY
Alignment/HIPAlignmentAlgorithm_relbigobj+=AlignmentHIPAlignmentAlgorithm
endif
ifeq ($(strip $(HIPAlignmentAlgorithmPlugins)),)
HIPAlignmentAlgorithmPlugins := self/src/Alignment/HIPAlignmentAlgorithm/plugins
HIPAlignmentAlgorithmPlugins_LOC_USE := self cmssw  FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry CommonTools/UtilAlgos DataFormats/VertexReco DataFormats/TrackReco TrackingTools/TrajectoryState TrackingTools/GeomPropagators TrackingTools/TransientTrack TrackingTools/Records RecoVertex/KalmanVertexFit RecoVertex/VertexPrimitives rootmath rootcore
ALL_EXTERNAL_PLUGIN_PRODS += HIPAlignmentAlgorithmPlugins
Alignment/HIPAlignmentAlgorithm_relbigobj+=HIPAlignmentAlgorithmPlugins
endif
ifeq ($(strip $(Alignment/MillePedeAlignmentAlgorithm)),)
AlignmentMillePedeAlignmentAlgorithm := self/Alignment/MillePedeAlignmentAlgorithm
Alignment/MillePedeAlignmentAlgorithm := AlignmentMillePedeAlignmentAlgorithm
AlignmentMillePedeAlignmentAlgorithm_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
AlignmentMillePedeAlignmentAlgorithm_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
AlignmentMillePedeAlignmentAlgorithm_EX_USE := $(foreach d, self cmssw  Alignment/CommonAlignment Alignment/CommonAlignmentAlgorithm Alignment/CommonAlignmentParametrization Alignment/MuonAlignment Alignment/ReferenceTrajectories CondFormats/PCLConfig DataFormats/CLHEP DataFormats/SiStripDetId DataFormats/GeometryVector DataFormats/TrackReco FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager rootcore,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
AlignmentMillePedeAlignmentAlgorithm_EX_LIB   := AlignmentMillePedeAlignmentAlgorithm
ALL_EXTERNAL_PRODS += AlignmentMillePedeAlignmentAlgorithm
AlignmentMillePedeAlignmentAlgorithm_CLASS := LIBRARY
Alignment/MillePedeAlignmentAlgorithm_relbigobj+=AlignmentMillePedeAlignmentAlgorithm
endif
ifeq ($(strip $(AlignmentMillePedeAlignmentAlgorithmAuto)),)
AlignmentMillePedeAlignmentAlgorithmAuto := self/src/Alignment/MillePedeAlignmentAlgorithm/plugins
AlignmentMillePedeAlignmentAlgorithmAuto_LOC_USE := self cmssw  Alignment/SurveyAnalysis FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry CommonTools/UtilAlgos CondFormats/Common CondFormats/GeometryObjects DataFormats/HepMCCandidate DataFormats/TrackerCommon Geometry/TrackerGeometryBuilder DQMServices/Core Alignment/MillePedeAlignmentAlgorithm
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentMillePedeAlignmentAlgorithmAuto
Alignment/MillePedeAlignmentAlgorithm_relbigobj+=AlignmentMillePedeAlignmentAlgorithmAuto
endif
ifeq ($(strip $(Alignment/OfflineValidation)),)
AlignmentOfflineValidation := self/Alignment/OfflineValidation
Alignment/OfflineValidation := AlignmentOfflineValidation
AlignmentOfflineValidation_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
AlignmentOfflineValidation_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
AlignmentOfflineValidation_EX_USE := $(foreach d, self cmssw  DataFormats/TrackReco FWCore/Framework FWCore/Utilities FWCore/ParameterSet Geometry/TrackerGeometryBuilder TrackingTools/PatternTools TrackingTools/TrackFitters MagneticField/Engine Alignment/TrackerAlignment CondFormats/Alignment DataFormats/GeometryCommonDetAlgo DataFormats/GeometrySurface DataFormats/Math DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/TrackerRecHit2D FWCore/MessageLogger Geometry/CommonTopologies Geometry/Records MagneticField/Records TrackingTools/GeomPropagators TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit clhep rootmath roothistmatrix rootgraphics roofit,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
AlignmentOfflineValidation_LCGDICTS  := x 
AlignmentOfflineValidation_EX_LIB   := AlignmentOfflineValidation
ALL_EXTERNAL_PRODS += AlignmentOfflineValidation
AlignmentOfflineValidation_CLASS := LIBRARY
Alignment/OfflineValidation_relbigobj+=AlignmentOfflineValidation
endif
ifeq ($(strip $(AlignmentOfflinevalidationPlugins)),)
AlignmentOfflinevalidationPlugins := self/src/Alignment/OfflineValidation/plugins
AlignmentOfflinevalidationPlugins_LOC_USE := self cmssw  Alignment/CommonAlignment Alignment/TrackerAlignment clhep CalibTracker/StandaloneTrackerTopology CommonTools/TrackerMap CommonTools/UtilAlgos CommonTools/Utils CondCore/DBOutputService CondFormats/Alignment CondFormats/BeamSpotObjects CondFormats/RunInfo CondFormats/SiPixelObjects CondCore/SiPixelPlugins CalibTracker/SiStripCommon DQM/TrackerRemapper DQM/SiPixelPhase1Common DQMServices/Core DataFormats/BeamSpot DataFormats/DetId DataFormats/EgammaCandidates DataFormats/MuonDetId DataFormats/MuonReco DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrajectorySeed DataFormats/VertexReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry FWCore/Utilities Geometry/CaloGeometry Geometry/CommonTopologies Geometry/Records Geometry/TrackerGeometryBuilder Geometry/TrackerNumberingBuilder HLTrigger/HLTcore MagneticField/Records RecoEcal/EgammaCoreTools RecoMuon/TrackingTools RecoVertex/PrimaryVertexProducer SimDataFormats/GeneratorProducts SimDataFormats/Track SimTracker/TrackerHitAssociation TrackPropagation/SteppingHelixPropagator TrackingTools/IPTools TrackingTools/TrackAssociator TrackingTools/TrackFitters TrackingTools/TrajectoryState TrackingTools/TransientTrack root rootcore rootmath rootrflx Alignment/OfflineValidation CondFormats/GeometryObjects
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentOfflinevalidationPlugins
Alignment/OfflineValidation_relbigobj+=AlignmentOfflinevalidationPlugins
endif
ifeq ($(strip $(Alignment/CommonAlignmentProducer)),)
AlignmentCommonAlignmentProducer := self/Alignment/CommonAlignmentProducer
Alignment/CommonAlignmentProducer := AlignmentCommonAlignmentProducer
AlignmentCommonAlignmentProducer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
AlignmentCommonAlignmentProducer_EX_USE := $(foreach d, self cmssw  Alignment/CommonAlignment Alignment/CommonAlignmentAlgorithm Alignment/CommonAlignmentMonitor Alignment/CommonAlignmentParametrization Alignment/MuonAlignment Alignment/TrackerAlignment CondCore/DBOutputService CondFormats/Alignment CondFormats/AlignmentRecord CondFormats/GeometryObjects DataFormats/Alignment DataFormats/Candidate DataFormats/Math DataFormats/MuonDetId DataFormats/MuonReco DataFormats/RecoCandidate DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry FWCore/Utilities Geometry/Records RecoVertex/KalmanVertexFit TrackingTools/Records TrackingTools/TransientTrack rootcore root,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
AlignmentCommonAlignmentProducer_EX_LIB   := AlignmentCommonAlignmentProducer
ALL_EXTERNAL_PRODS += AlignmentCommonAlignmentProducer
AlignmentCommonAlignmentProducer_CLASS := LIBRARY
Alignment/CommonAlignmentProducer_relbigobj+=AlignmentCommonAlignmentProducer
endif
ifeq ($(strip $(AlignmentCommonAlignmentFakeProducers)),)
AlignmentCommonAlignmentFakeProducers := self/src/Alignment/CommonAlignmentProducer/plugins
AlignmentCommonAlignmentFakeProducers_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondFormats/Alignment CondFormats/AlignmentRecord
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentCommonAlignmentFakeProducers
Alignment/CommonAlignmentProducer_relbigobj+=AlignmentCommonAlignmentFakeProducers
endif
ifeq ($(strip $(AlignmentCommonAlignmentProducerAsAnalyzerPlugin)),)
AlignmentCommonAlignmentProducerAsAnalyzerPlugin := self/src/Alignment/CommonAlignmentProducer/plugins
AlignmentCommonAlignmentProducerAsAnalyzerPlugin_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet Alignment/CommonAlignmentProducer
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentCommonAlignmentProducerAsAnalyzerPlugin
Alignment/CommonAlignmentProducer_relbigobj+=AlignmentCommonAlignmentProducerAsAnalyzerPlugin
endif
ifeq ($(strip $(AlignmentCommonAlignmentProducerFilter)),)
AlignmentCommonAlignmentProducerFilter := self/src/Alignment/CommonAlignmentProducer/plugins
AlignmentCommonAlignmentProducerFilter_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet HLTrigger/HLTcore
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentCommonAlignmentProducerFilter
Alignment/CommonAlignmentProducer_relbigobj+=AlignmentCommonAlignmentProducerFilter
endif
ifeq ($(strip $(AlignmentCommonAlignmentProducerGlobal)),)
AlignmentCommonAlignmentProducerGlobal := self/src/Alignment/CommonAlignmentProducer/plugins
AlignmentCommonAlignmentProducerGlobal_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet root FWCore/ServiceRegistry Geometry/Records MagneticField/Engine MagneticField/Records TrackingTools/GeomPropagators TrackingTools/Records TrackingTools/TransientTrack TrackingTools/TrackFitters TrackingTools/KalmanUpdators TrackPropagation/SteppingHelixPropagator TrackPropagation/RungeKutta CondFormats/AlignmentRecord CondFormats/Alignment CondCore/DBOutputService DataFormats/DetId DataFormats/TrackReco RecoMuon/TransientTrackingRecHit
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentCommonAlignmentProducerGlobal
Alignment/CommonAlignmentProducer_relbigobj+=AlignmentCommonAlignmentProducerGlobal
endif
ifeq ($(strip $(AlignmentCommonAlignmentProducerPlugin)),)
AlignmentCommonAlignmentProducerPlugin := self/src/Alignment/CommonAlignmentProducer/plugins
AlignmentCommonAlignmentProducerPlugin_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet Geometry/Records Alignment/CommonAlignmentProducer
ALL_EXTERNAL_PLUGIN_PRODS += AlignmentCommonAlignmentProducerPlugin
Alignment/CommonAlignmentProducer_relbigobj+=AlignmentCommonAlignmentProducerPlugin
endif
ifeq ($(strip $(CommonAlignmentProducerSelectors)),)
CommonAlignmentProducerSelectors := self/src/Alignment/CommonAlignmentProducer/plugins
CommonAlignmentProducerSelectors_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet Alignment/CommonAlignmentProducer DataFormats/DetId DataFormats/MuonDetId DataFormats/TrackingRecHit DataFormats/TrackReco FWCore/ServiceRegistry CommonTools/UtilAlgos CommonTools/RecoAlgos TrackingTools/PatternTools TrackingTools/TrackFitters TrackingTools/TransientTrackingRecHit root
ALL_EXTERNAL_PLUGIN_PRODS += CommonAlignmentProducerSelectors
Alignment/CommonAlignmentProducer_relbigobj+=CommonAlignmentProducerSelectors
endif
ifeq ($(strip $(CalibTracker/SiStripHitResolution)),)
CalibTrackerSiStripHitResolution := self/CalibTracker/SiStripHitResolution
CalibTracker/SiStripHitResolution := CalibTrackerSiStripHitResolution
CalibTrackerSiStripHitResolution_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CalibTrackerSiStripHitResolution_EX_USE := $(foreach d, self cmssw  CommonTools/Statistics CommonTools/UtilAlgos DataFormats/Common DataFormats/SiStripDetId DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit FWCore/Framework FWCore/ParameterSet Geometry/CommonDetUnit Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Engine MagneticField/Records RecoTracker/MeasurementDet RecoTracker/Record TrackingTools/AnalyticalJacobians TrackingTools/PatternTools TrackingTools/TrackFitters TrackingTools/TrajectoryState root,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CalibTrackerSiStripHitResolution_EX_LIB   := CalibTrackerSiStripHitResolution
ALL_EXTERNAL_PRODS += CalibTrackerSiStripHitResolution
CalibTrackerSiStripHitResolution_CLASS := LIBRARY
CalibTracker/SiStripHitResolution_relbigobj+=CalibTrackerSiStripHitResolution
endif
ifeq ($(strip $(CalibTrackerSiStripHitResolutionAuto)),)
CalibTrackerSiStripHitResolutionAuto := self/src/CalibTracker/SiStripHitResolution/plugins
CalibTrackerSiStripHitResolutionAuto_LOC_USE := self cmssw  CalibTracker/SiStripCommon CalibTracker/SiStripHitResolution CommonTools/ConditionDBWriter CommonTools/TrackerMap CommonTools/UtilAlgos DataFormats/Common DataFormats/Scalers DataFormats/SiStripCluster DataFormats/SiStripDetId DataFormats/TrackReco FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry Geometry/Records Geometry/TrackerGeometryBuilder RecoLocalTracker/ClusterParameterEstimator RecoLocalTracker/Records TrackingTools/DetLayers TrackingTools/PatternTools
ALL_EXTERNAL_PLUGIN_PRODS += CalibTrackerSiStripHitResolutionAuto
CalibTracker/SiStripHitResolution_relbigobj+=CalibTrackerSiStripHitResolutionAuto
endif
ifeq ($(strip $(CalibTracker/SiStripHitEfficiency)),)
CalibTrackerSiStripHitEfficiency := self/CalibTracker/SiStripHitEfficiency
CalibTracker/SiStripHitEfficiency := CalibTrackerSiStripHitEfficiency
CalibTrackerSiStripHitEfficiency_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CalibTrackerSiStripHitEfficiency_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
CalibTrackerSiStripHitEfficiency_EX_USE := $(foreach d, self cmssw  DataFormats/SiStripDetId DQM/SiStripCommon RecoTracker/TransientTrackingRecHit TrackingTools/TrackFitters,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CalibTrackerSiStripHitEfficiency_EX_LIB   := CalibTrackerSiStripHitEfficiency
ALL_EXTERNAL_PRODS += CalibTrackerSiStripHitEfficiency
CalibTrackerSiStripHitEfficiency_CLASS := LIBRARY
CalibTracker/SiStripHitEfficiency_relbigobj+=CalibTrackerSiStripHitEfficiency
endif
ifeq ($(strip $(CalibTrackerSiStripHitEffPlugins)),)
CalibTrackerSiStripHitEffPlugins := self/src/CalibTracker/SiStripHitEfficiency/plugins
CalibTrackerSiStripHitEffPlugins_LOC_USE := self cmssw  CalibTracker/SiStripCommon CalibTracker/SiStripHitEfficiency CommonTools/ConditionDBWriter CommonTools/TrackerMap CommonTools/UtilAlgos DataFormats/DetId DataFormats/Scalers DataFormats/SiStripDetId DataFormats/TrackingRecHit DataFormats/TrackReco DataFormats/Common DQMServices/Core DQM/SiStripCommon FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Engine MagneticField/Records RecoLocalTracker/SiStripClusterizer RecoTracker/Record RecoTracker/MeasurementDet TrackingTools/PatternTools TrackingTools/KalmanUpdators TrackingTools/MeasurementDet
ALL_EXTERNAL_PLUGIN_PRODS += CalibTrackerSiStripHitEffPlugins
CalibTracker/SiStripHitEfficiency_relbigobj+=CalibTrackerSiStripHitEffPlugins
endif
ifeq ($(strip $(Calibration/Tools)),)
CalibrationTools := self/Calibration/Tools
Calibration/Tools := CalibrationTools
CalibrationTools_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CalibrationTools_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/ParameterSet DataFormats/CaloTowers DataFormats/DetId DataFormats/EcalRecHit DataFormats/EgammaCandidates DataFormats/EgammaReco DataFormats/GeometrySurface rootcore rootminuit rootgraphics Geometry/CaloGeometry Geometry/HcalTowerAlgo TrackingTools/GeomPropagators,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CalibrationTools_EX_LIB   := CalibrationTools
ALL_EXTERNAL_PRODS += CalibrationTools
CalibrationTools_CLASS := LIBRARY
Calibration/Tools_relbigobj+=CalibrationTools
endif
ifeq ($(strip $(CalibrationToolsPlugins)),)
CalibrationToolsPlugins := self/src/Calibration/Tools/plugins
CalibrationToolsPlugins_LOC_USE := self cmssw  Calibration/Tools CommonTools/RecoAlgos DataFormats/EgammaCandidates FWCore/Framework FWCore/PluginManager CommonTools/UtilAlgos clhep rootcore rootmath
ALL_EXTERNAL_PLUGIN_PRODS += CalibrationToolsPlugins
Calibration/Tools_relbigobj+=CalibrationToolsPlugins
endif
ifeq ($(strip $(Calibration/TkAlCaRecoProducers)),)
CalibrationTkAlCaRecoProducers := self/Calibration/TkAlCaRecoProducers
Calibration/TkAlCaRecoProducers := CalibrationTkAlCaRecoProducers
CalibrationTkAlCaRecoProducers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
CalibrationTkAlCaRecoProducers_EX_USE := $(foreach d, self cmssw  DataFormats/DetId DataFormats/SiStripDetId DataFormats/SiPixelDetId DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/SiStripCluster DataFormats/BeamSpot FWCore/MessageLogger FWCore/Framework FWCore/Utilities FWCore/ParameterSet rootcore,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
CalibrationTkAlCaRecoProducers_EX_LIB   := CalibrationTkAlCaRecoProducers
ALL_EXTERNAL_PRODS += CalibrationTkAlCaRecoProducers
CalibrationTkAlCaRecoProducers_CLASS := LIBRARY
Calibration/TkAlCaRecoProducers_relbigobj+=CalibrationTkAlCaRecoProducers
endif
ifeq ($(strip $(AlcaBeamSpotFromDB)),)
AlcaBeamSpotFromDB := self/src/Calibration/TkAlCaRecoProducers/plugins
AlcaBeamSpotFromDB_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers
ALL_EXTERNAL_PLUGIN_PRODS += AlcaBeamSpotFromDB
Calibration/TkAlCaRecoProducers_relbigobj+=AlcaBeamSpotFromDB
endif
ifeq ($(strip $(AlcaBeamSpotHarvester)),)
AlcaBeamSpotHarvester := self/src/Calibration/TkAlCaRecoProducers/plugins
AlcaBeamSpotHarvester_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers
ALL_EXTERNAL_PLUGIN_PRODS += AlcaBeamSpotHarvester
Calibration/TkAlCaRecoProducers_relbigobj+=AlcaBeamSpotHarvester
endif
ifeq ($(strip $(AlcaBeamSpotProducer)),)
AlcaBeamSpotProducer := self/src/Calibration/TkAlCaRecoProducers/plugins
AlcaBeamSpotProducer_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers
ALL_EXTERNAL_PLUGIN_PRODS += AlcaBeamSpotProducer
Calibration/TkAlCaRecoProducers_relbigobj+=AlcaBeamSpotProducer
endif
ifeq ($(strip $(CalibrationTrackSelectorFromDetIdList)),)
CalibrationTrackSelectorFromDetIdList := self/src/Calibration/TkAlCaRecoProducers/plugins
CalibrationTrackSelectorFromDetIdList_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers MagneticField/Records TrackingTools/TrajectoryState
ALL_EXTERNAL_PLUGIN_PRODS += CalibrationTrackSelectorFromDetIdList
Calibration/TkAlCaRecoProducers_relbigobj+=CalibrationTrackSelectorFromDetIdList
endif
ifeq ($(strip $(CalibrationTrackSelectorModule)),)
CalibrationTrackSelectorModule := self/src/Calibration/TkAlCaRecoProducers/plugins
CalibrationTrackSelectorModule_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers CommonTools/RecoAlgos
ALL_EXTERNAL_PLUGIN_PRODS += CalibrationTrackSelectorModule
Calibration/TkAlCaRecoProducers_relbigobj+=CalibrationTrackSelectorModule
endif
ifeq ($(strip $(NearbyPixelClustersAnalyzer)),)
NearbyPixelClustersAnalyzer := self/src/Calibration/TkAlCaRecoProducers/plugins
NearbyPixelClustersAnalyzer_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers TrackingTools/PatternTools RecoLocalTracker/ClusterParameterEstimator RecoLocalTracker/Records TrackingTools/TrackFitters CondFormats/SiPixelObjects CalibTracker/SiPixelESProducers
ALL_EXTERNAL_PLUGIN_PRODS += NearbyPixelClustersAnalyzer
Calibration/TkAlCaRecoProducers_relbigobj+=NearbyPixelClustersAnalyzer
endif
ifeq ($(strip $(NearbyPixelClustersProducer)),)
NearbyPixelClustersProducer := self/src/Calibration/TkAlCaRecoProducers/plugins
NearbyPixelClustersProducer_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers TrackingTools/PatternTools RecoLocalTracker/ClusterParameterEstimator RecoLocalTracker/Records TrackingTools/TrackFitters
ALL_EXTERNAL_PLUGIN_PRODS += NearbyPixelClustersProducer
Calibration/TkAlCaRecoProducers_relbigobj+=NearbyPixelClustersProducer
endif
ifeq ($(strip $(TrackDistanceValueMapProducer)),)
TrackDistanceValueMapProducer := self/src/Calibration/TkAlCaRecoProducers/plugins
TrackDistanceValueMapProducer_LOC_USE := self cmssw  FWCore/MessageLogger FWCore/Framework FWCore/ParameterSet CondCore/Utilities FWCore/ServiceRegistry CondFormats/BeamSpotObjects CondFormats/DataRecord CondCore/DBOutputService CommonTools/UtilAlgos RecoVertex/BeamSpotProducer Calibration/TkAlCaRecoProducers DataFormats/TrackReco
ALL_EXTERNAL_PLUGIN_PRODS += TrackDistanceValueMapProducer
Calibration/TkAlCaRecoProducers_relbigobj+=TrackDistanceValueMapProducer
endif
ifeq ($(strip $(CalibrationHcalIsolatedTrackRecoPlugins)),)
CalibrationHcalIsolatedTrackRecoPlugins := self/src/Calibration/HcalIsolatedTrackReco/plugins
CalibrationHcalIsolatedTrackRecoPlugins_LOC_USE := self cmssw  DataFormats/Common DataFormats/HcalIsolatedTrack DataFormats/L1Trigger DataFormats/L1GlobalTrigger FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager FWCore/Utilities DataFormats/DetId DataFormats/EcalRecHit DataFormats/EcalDetId Geometry/CaloGeometry Geometry/CaloTopology DataFormats/HLTReco DataFormats/VertexReco Geometry/EcalMapping Geometry/EcalAlgo DataFormats/EcalRawData DataFormats/FEDRawData MagneticField/Records MagneticField/VolumeBasedEngine RecoTracker/TkTrackingRegions rootmath
ALL_EXTERNAL_PLUGIN_PRODS += CalibrationHcalIsolatedTrackRecoPlugins
Calibration/HcalIsolatedTrackReco_relbigobj+=CalibrationHcalIsolatedTrackRecoPlugins
endif
ifeq ($(strip $(RecoEgamma/EgammaPhotonProducers)),)
RecoEgammaEgammaPhotonProducers := self/RecoEgamma/EgammaPhotonProducers
RecoEgamma/EgammaPhotonProducers := RecoEgammaEgammaPhotonProducers
RecoEgammaEgammaPhotonProducers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoEgammaEgammaPhotonProducers_EX_FLAGS_USE_SOURCE_ONLY   := RecoCaloTools/Selectors
RecoEgammaEgammaPhotonProducers_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/ParameterSet DataFormats/ParticleFlowCandidate DataFormats/EgammaCandidates DataFormats/Common DataFormats/TrackCandidate DataFormats/TrackReco DataFormats/EgammaTrackReco DataFormats/CaloRecHit DataFormats/Math Geometry/CaloGeometry Geometry/CaloTopology RecoEcal/EgammaCoreTools RecoEgamma/EgammaIsolationAlgos RecoEgamma/EgammaElectronAlgos RecoEgamma/EgammaPhotonAlgos RecoEgamma/PhotonIdentification RecoEgamma/EgammaTools RecoTracker/MeasurementDet RecoTracker/CkfPattern RecoTracker/TrackProducer DataFormats/HcalRecHit clhep PhysicsTools/TensorFlow,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoEgammaEgammaPhotonProducers
RecoEgammaEgammaPhotonProducers_CLASS := LIBRARY
RecoEgamma/EgammaPhotonProducers_relbigobj+=RecoEgammaEgammaPhotonProducers
endif
ifeq ($(strip $(RecoEgamma/EgammaPhotonAlgos)),)
RecoEgammaEgammaPhotonAlgos := self/RecoEgamma/EgammaPhotonAlgos
RecoEgamma/EgammaPhotonAlgos := RecoEgammaEgammaPhotonAlgos
RecoEgammaEgammaPhotonAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoEgammaEgammaPhotonAlgos_EX_USE := $(foreach d, self cmssw  ofast-flag FWCore/Framework FWCore/ParameterSet Geometry/CaloGeometry Geometry/CaloTopology DataFormats/CaloRecHit CommonTools/CandAlgos RecoEgamma/EgammaTools DataFormats/Math DataFormats/EgammaCandidates DataFormats/Common DataFormats/TrajectorySeed TrackingTools/MaterialEffects TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/TrajectoryState TrackingTools/PatternTools TrackingTools/DetLayers TrackingTools/TransientTrack RecoTracker/MeasurementDet RecoTracker/CkfPattern RecoTracker/TkSeedGenerator RecoVertex/VertexPrimitives RecoVertex/KalmanVertexFit RecoVertex/KinematicFitPrimitives RecoVertex/KinematicFit MagneticField/Engine Utilities/General clhep,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoEgammaEgammaPhotonAlgos_EX_LIB   := RecoEgammaEgammaPhotonAlgos
ALL_EXTERNAL_PRODS += RecoEgammaEgammaPhotonAlgos
RecoEgammaEgammaPhotonAlgos_CLASS := LIBRARY
RecoEgamma/EgammaPhotonAlgos_relbigobj+=RecoEgammaEgammaPhotonAlgos
endif
ifeq ($(strip $(RecoEgamma/EgammaElectronAlgos)),)
RecoEgammaEgammaElectronAlgos := self/RecoEgamma/EgammaElectronAlgos
RecoEgamma/EgammaElectronAlgos := RecoEgammaEgammaElectronAlgos
RecoEgammaEgammaElectronAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoEgammaEgammaElectronAlgos_EX_USE := $(foreach d, self cmssw  ofast-flag TrackingTools/MaterialEffects FWCore/Framework FWCore/ParameterSet clhep MagneticField/Engine DataFormats/DetId DataFormats/TrackingRecHit DataFormats/GsfTrackReco DataFormats/TrackReco DataFormats/EgammaReco DataFormats/EgammaCandidates DataFormats/CaloRecHit Geometry/TrackerGeometryBuilder Geometry/CaloGeometry Geometry/CaloTopology RecoTracker/MeasurementDet TrackingTools/DetLayers TrackingTools/GsfTools TrackingTools/GsfTracking DataFormats/HcalRecHit RecoEcal/EgammaCoreTools RecoEgamma/EgammaTools RecoEgamma/EgammaIsolationAlgos RecoEgamma/ElectronIdentification CondFormats/GBRForest CondFormats/DataRecord CommonTools/Egamma,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoEgammaEgammaElectronAlgos_EX_LIB   := RecoEgammaEgammaElectronAlgos
ALL_EXTERNAL_PRODS += RecoEgammaEgammaElectronAlgos
RecoEgammaEgammaElectronAlgos_CLASS := LIBRARY
RecoEgamma/EgammaElectronAlgos_relbigobj+=RecoEgammaEgammaElectronAlgos
endif
ifeq ($(strip $(RecoEgamma/EgammaElectronProducers)),)
RecoEgammaEgammaElectronProducers := self/RecoEgamma/EgammaElectronProducers
RecoEgamma/EgammaElectronProducers := RecoEgammaEgammaElectronProducers
RecoEgammaEgammaElectronProducers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoEgammaEgammaElectronProducers_EX_USE := $(foreach d, self cmssw  CommonTools/BaseParticlePropagator DataFormats/BeamSpot DataFormats/Common DataFormats/EgammaCandidates DataFormats/GsfTrackReco DataFormats/ParticleFlowReco DataFormats/TrackReco RecoEcal/EgammaCoreTools,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoEgammaEgammaElectronProducers_EX_LIB   := RecoEgammaEgammaElectronProducers
ALL_EXTERNAL_PRODS += RecoEgammaEgammaElectronProducers
RecoEgammaEgammaElectronProducers_CLASS := LIBRARY
RecoEgamma/EgammaElectronProducers_relbigobj+=RecoEgammaEgammaElectronProducers
endif
ifeq ($(strip $(RecoEgammaEgammaElectronProducersPlugins)),)
RecoEgammaEgammaElectronProducersPlugins := self/src/RecoEgamma/EgammaElectronProducers/plugins
RecoEgammaEgammaElectronProducersPlugins_LOC_USE := self cmssw  CommonTools/CandAlgos CommonTools/ParticleFlow DataFormats/BeamSpot DataFormats/Candidate DataFormats/Common DataFormats/EcalRecHit DataFormats/EgammaCandidates DataFormats/PatCandidates DataFormats/EgammaReco DataFormats/GeometryVector DataFormats/GsfTrackReco DataFormats/Math DataFormats/ParticleFlowCandidate DataFormats/ParticleFlowReco DataFormats/TrackReco CommonTools/BaseParticlePropagator FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities MagneticField/Engine MagneticField/Records RecoEcal/EgammaCoreTools RecoEgamma/EgammaElectronAlgos RecoEgamma/EgammaElectronProducers RecoEgamma/EgammaIsolationAlgos RecoTracker/TkTrackingRegions RecoTracker/TransientTrackingRecHit TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryParametrization TrackingTools/TrajectoryState
ALL_EXTERNAL_PLUGIN_PRODS += RecoEgammaEgammaElectronProducersPlugins
RecoEgamma/EgammaElectronProducers_relbigobj+=RecoEgammaEgammaElectronProducersPlugins
endif
ifeq ($(strip $(RecoEgamma/ElectronIdentification)),)
RecoEgammaElectronIdentification := self/RecoEgamma/ElectronIdentification
RecoEgamma/ElectronIdentification := RecoEgammaElectronIdentification
RecoEgammaElectronIdentification_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoEgammaElectronIdentification_EX_USE := $(foreach d, self cmssw  CondFormats/GBRForest DataFormats/TrackReco CommonTools/MVAUtils RecoEgamma/EgammaTools CommonTools/Utils DataFormats/EgammaCandidates DataFormats/GsfTrackReco DataFormats/PatCandidates DataFormats/VertexReco PhysicsTools/TensorFlow,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoEgammaElectronIdentification_EX_LIB   := RecoEgammaElectronIdentification
ALL_EXTERNAL_PRODS += RecoEgammaElectronIdentification
RecoEgammaElectronIdentification_CLASS := LIBRARY
RecoEgamma/ElectronIdentification_relbigobj+=RecoEgammaElectronIdentification
endif
ifeq ($(strip $(RecoEgammaElectronIdentificationPlugins)),)
RecoEgammaElectronIdentificationPlugins := self/src/RecoEgamma/ElectronIdentification/plugins
RecoEgammaElectronIdentificationPlugins_LOC_USE := self cmssw  CommonTools/Egamma CommonTools/UtilAlgos DataFormats/Common DataFormats/EcalRecHit DataFormats/EgammaCandidates FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry PhysicsTools/SelectorUtils RecoEgamma/EgammaIsolationAlgos RecoEgamma/EgammaTools RecoEgamma/ElectronIdentification root rootcore
ALL_EXTERNAL_PLUGIN_PRODS += RecoEgammaElectronIdentificationPlugins
RecoEgamma/ElectronIdentification_relbigobj+=RecoEgammaElectronIdentificationPlugins
endif
ifeq ($(strip $(RecoEgammaElectronIdentificationPlugins_cuts)),)
RecoEgammaElectronIdentificationPlugins_cuts := self/src/RecoEgamma/ElectronIdentification/plugins
RecoEgammaElectronIdentificationPlugins_cuts_LOC_USE := self cmssw  CommonTools/Egamma CommonTools/UtilAlgos DataFormats/Common DataFormats/EcalRecHit DataFormats/EgammaCandidates FWCore/Framework FWCore/ParameterSet FWCore/ServiceRegistry PhysicsTools/SelectorUtils RecoEgamma/EgammaIsolationAlgos RecoEgamma/EgammaTools RecoEgamma/ElectronIdentification root rootcore
ALL_EXTERNAL_PLUGIN_PRODS += RecoEgammaElectronIdentificationPlugins_cuts
RecoEgamma/ElectronIdentification_relbigobj+=RecoEgammaElectronIdentificationPlugins_cuts
endif
ifeq ($(strip $(RecoMuon/L3MuonProducer)),)
RecoMuonL3MuonProducer := self/RecoMuon/L3MuonProducer
RecoMuon/L3MuonProducer := RecoMuonL3MuonProducer
RecoMuonL3MuonProducer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonL3MuonProducer_EX_USE := $(foreach d, self cmssw  DataFormats/Common DataFormats/MuonReco DataFormats/RecoCandidate DataFormats/TrackReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager RecoMuon/L3TrackFinder RecoMuon/TrackingTools TrackingTools/PatternTools,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoMuonL3MuonProducer
RecoMuonL3MuonProducer_CLASS := LIBRARY
RecoMuon/L3MuonProducer_relbigobj+=RecoMuonL3MuonProducer
endif
ifeq ($(strip $(RecoMuon/L3TrackFinder)),)
RecoMuonL3TrackFinder := self/RecoMuon/L3TrackFinder
RecoMuon/L3TrackFinder := RecoMuonL3TrackFinder
RecoMuonL3TrackFinder_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonL3TrackFinder_EX_USE := $(foreach d, self cmssw  DataFormats/TrackReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry RecoMuon/GlobalTrackingTools RecoMuon/TrackingTools RecoTracker/CkfPattern RecoTracker/MeasurementDet RecoTracker/Record RecoTracker/TkDetLayers RecoTracker/TkTrackingRegions TrackingTools/DetLayers TrackingTools/KalmanUpdators TrackingTools/MeasurementDet TrackingTools/PatternTools TrackingTools/TrajectoryCleaning TrackingTools/TrajectoryFiltering TrackingTools/TrajectoryState,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoMuonL3TrackFinder_EX_LIB   := RecoMuonL3TrackFinder
ALL_EXTERNAL_PRODS += RecoMuonL3TrackFinder
RecoMuonL3TrackFinder_CLASS := LIBRARY
RecoMuon/L3TrackFinder_relbigobj+=RecoMuonL3TrackFinder
endif
ifeq ($(strip $(RecoMuonL3TrackFinderPlugins)),)
RecoMuonL3TrackFinderPlugins := self/src/RecoMuon/L3TrackFinder/plugins
RecoMuonL3TrackFinderPlugins_LOC_USE := self cmssw  FWCore/Framework RecoMuon/L3TrackFinder
ALL_EXTERNAL_PLUGIN_PRODS += RecoMuonL3TrackFinderPlugins
RecoMuon/L3TrackFinder_relbigobj+=RecoMuonL3TrackFinderPlugins
endif
ifeq ($(strip $(RecoMuon/GlobalMuonProducer)),)
RecoMuonGlobalMuonProducer := self/RecoMuon/GlobalMuonProducer
RecoMuon/GlobalMuonProducer := RecoMuonGlobalMuonProducer
RecoMuonGlobalMuonProducer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonGlobalMuonProducer_EX_USE := $(foreach d, self cmssw  DataFormats/Common DataFormats/MuonReco DataFormats/TrackReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager RecoMuon/GlobalTrackFinder RecoMuon/GlobalTrackingTools RecoMuon/TrackingTools TrackingTools/PatternTools,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoMuonGlobalMuonProducer
RecoMuonGlobalMuonProducer_CLASS := LIBRARY
RecoMuon/GlobalMuonProducer_relbigobj+=RecoMuonGlobalMuonProducer
endif
ifeq ($(strip $(RecoMuon/TrackerSeedGenerator)),)
RecoMuonTrackerSeedGenerator := self/RecoMuon/TrackerSeedGenerator
RecoMuon/TrackerSeedGenerator := RecoMuonTrackerSeedGenerator
RecoMuonTrackerSeedGenerator_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonTrackerSeedGenerator_EX_USE := $(foreach d, self cmssw  CommonTools/MVAUtils CommonTools/Utils CommonTools/UtilAlgos DataFormats/BeamSpot DataFormats/Common DataFormats/GeometryCommonDetAlgo DataFormats/GeometryVector DataFormats/L1Trigger DataFormats/L1GlobalMuonTrigger DataFormats/MuonReco DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrajectorySeed DataFormats/TrajectoryState DataFormats/TrackerCommon DataFormats/RecoCandidate DataFormats/SiPixelDetId DataFormats/Phase2TrackerDigi DataFormats/L1TrackTrigger DataFormats/L1TCorrelator DataFormats/L1TMuonPhase2 FWCore/Framework FWCore/Utilities FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager Geometry/Records Geometry/TrackerGeometryBuilder Geometry/TrackerNumberingBuilder Geometry/CommonDetUnit Geometry/CommonTopologies MagneticField/Engine MagneticField/Records RecoMuon/DetLayers RecoMuon/TrackingTools RecoMuon/Records RecoTracker/PixelTrackFitting RecoTracker/TkMSParametrization RecoTracker/TkDetLayers RecoTracker/TkSeedingLayers RecoTracker/TkTrackingRegions RecoTracker/TransientTrackingRecHit SimTracker/Common SimTracker/TrackAssociation SimTracker/TrackerHitAssociation SimTracker/TrackTriggerAssociation SimDataFormats/Associations SimDataFormats/TrackingAnalysis SimGeneral/TrackingAnalysis TrackingTools/GeomPropagators TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit TrackingTools/TrackAssociator TrackPropagation/SteppingHelixPropagator,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoMuonTrackerSeedGenerator_EX_LIB   := RecoMuonTrackerSeedGenerator
ALL_EXTERNAL_PRODS += RecoMuonTrackerSeedGenerator
RecoMuonTrackerSeedGenerator_CLASS := LIBRARY
RecoMuon/TrackerSeedGenerator_relbigobj+=RecoMuonTrackerSeedGenerator
endif
ifeq ($(strip $(RecoMuonTrackerSeedGeneratorPlugins)),)
RecoMuonTrackerSeedGeneratorPlugins := self/src/RecoMuon/TrackerSeedGenerator/plugins
RecoMuonTrackerSeedGeneratorPlugins_LOC_USE := self cmssw  CommonTools/MVAUtils CommonTools/Utils CommonTools/UtilAlgos DataFormats/Common DataFormats/L1TCorrelator DataFormats/L1TrackTrigger DataFormats/L1Trigger DataFormats/MuonSeed DataFormats/MuonReco DataFormats/Phase2TrackerDigi DataFormats/RecoCandidate DataFormats/SiPixelDetId DataFormats/TrackerCommon DataFormats/TrackReco DataFormats/TrackingRecHit DataFormats/TrajectorySeed DataFormats/TrajectoryState FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/PluginManager FWCore/Utilities Geometry/CommonTopologies Geometry/Records Geometry/TrackerGeometryBuilder Geometry/TrackerNumberingBuilder MagneticField/Engine MagneticField/Records RecoMuon/DetLayers RecoMuon/GlobalTrackingTools RecoMuon/Records RecoMuon/TrackerSeedGenerator RecoMuon/TrackingTools RecoTracker/MeasurementDet RecoTracker/PixelTrackFitting RecoTracker/Record RecoTracker/TkDetLayers RecoTracker/TkSeedGenerator RecoTracker/TkTrackingRegions SimDataFormats/Associations SimDataFormats/TrackingAnalysis SimGeneral/TrackingAnalysis SimTracker/Common SimTracker/TrackAssociation SimTracker/TrackerHitAssociation SimTracker/TrackTriggerAssociation TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/MeasurementDet TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrackAssociator TrackingTools/TrajectoryState TrackingTools/TransientTrack TrackPropagation/SteppingHelixPropagator PhysicsTools/TensorFlow roothistmatrix
ALL_EXTERNAL_PLUGIN_PRODS += RecoMuonTrackerSeedGeneratorPlugins
RecoMuon/TrackerSeedGenerator_relbigobj+=RecoMuonTrackerSeedGeneratorPlugins
endif
ifeq ($(strip $(RecoMuon/GlobalTrackFinder)),)
RecoMuonGlobalTrackFinder := self/RecoMuon/GlobalTrackFinder
RecoMuon/GlobalTrackFinder := RecoMuonGlobalTrackFinder
RecoMuonGlobalTrackFinder_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonGlobalTrackFinder_EX_USE := $(foreach d, self cmssw  DataFormats/TrackReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet RecoMuon/GlobalTrackingTools RecoMuon/TrackingTools TrackingTools/PatternTools,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoMuonGlobalTrackFinder_EX_LIB   := RecoMuonGlobalTrackFinder
ALL_EXTERNAL_PRODS += RecoMuonGlobalTrackFinder
RecoMuonGlobalTrackFinder_CLASS := LIBRARY
RecoMuon/GlobalTrackFinder_relbigobj+=RecoMuonGlobalTrackFinder
endif
ifeq ($(strip $(RecoMuon/GlobalTrackingTools)),)
RecoMuonGlobalTrackingTools := self/RecoMuon/GlobalTrackingTools
RecoMuon/GlobalTrackingTools := RecoMuonGlobalTrackingTools
RecoMuonGlobalTrackingTools_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonGlobalTrackingTools_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoMuonGlobalTrackingTools_EX_USE := $(foreach d, self cmssw  CommonTools/Statistics DataFormats/BeamSpot DataFormats/Common DataFormats/DetId DataFormats/GeometryCommonDetAlgo DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/Math DataFormats/MuonDetId DataFormats/TrackReco DataFormats/TrajectoryState DataFormats/VertexReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry Geometry/CSCGeometry Geometry/DTGeometry RecoMuon/Navigation RecoMuon/TrackingTools RecoMuon/TransientTrackingRecHit RecoTracker/TkDetLayers RecoTracker/TkMSParametrization RecoTracker/TkTrackingRegions RecoTracker/TransientTrackingRecHit TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrackFitters TrackingTools/TrackRefitter TrackingTools/TrajectoryState TrackingTools/TransientTrack TrackingTools/TransientTrackingRecHit CondFormats/RecoMuonObjects CondFormats/Alignment root,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoMuonGlobalTrackingTools_EX_LIB   := RecoMuonGlobalTrackingTools
ALL_EXTERNAL_PRODS += RecoMuonGlobalTrackingTools
RecoMuonGlobalTrackingTools_CLASS := LIBRARY
RecoMuon/GlobalTrackingTools_relbigobj+=RecoMuonGlobalTrackingTools
endif
ifeq ($(strip $(RecoMuonGlobalTrackingToolsPlugins)),)
RecoMuonGlobalTrackingToolsPlugins := self/src/RecoMuon/GlobalTrackingTools/plugins
RecoMuonGlobalTrackingToolsPlugins_LOC_USE := self cmssw  DataFormats/Common DataFormats/MuonReco DataFormats/TrackReco FWCore/Framework FWCore/ParameterSet FWCore/PluginManager Geometry/Records RecoMuon/TrackingTools RecoMuon/GlobalTrackingTools RecoVertex/KalmanVertexFit boost_regex
ALL_EXTERNAL_PLUGIN_PRODS += RecoMuonGlobalTrackingToolsPlugins
RecoMuon/GlobalTrackingTools_relbigobj+=RecoMuonGlobalTrackingToolsPlugins
endif
ifeq ($(strip $(RecoMuon/CosmicMuonProducer)),)
RecoMuonCosmicMuonProducer := self/RecoMuon/CosmicMuonProducer
RecoMuon/CosmicMuonProducer := RecoMuonCosmicMuonProducer
RecoMuonCosmicMuonProducer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoMuonCosmicMuonProducer_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoMuonCosmicMuonProducer_EX_USE := $(foreach d, self cmssw  DataFormats/CSCRecHit DataFormats/Common DataFormats/DTRecHit DataFormats/GeometryCommonDetAlgo DataFormats/GeometrySurface DataFormats/MuonDetId DataFormats/MuonReco DataFormats/TrackReco DataFormats/TrackerRecHit2D DataFormats/TrackingRecHit DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet RecoMuon/MeasurementDet RecoMuon/Navigation RecoMuon/TrackingTools RecoMuon/GlobalTrackingTools RecoMuon/TransientTrackingRecHit TrackingTools/DetLayers TrackingTools/GeomPropagators TrackingTools/KalmanUpdators TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrackFitters TrackingTools/TrajectoryState TrackingTools/TransientTrackingRecHit,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoMuonCosmicMuonProducer
RecoMuonCosmicMuonProducer_CLASS := LIBRARY
RecoMuon/CosmicMuonProducer_relbigobj+=RecoMuonCosmicMuonProducer
endif
ifeq ($(strip $(SimG4CMS/Calo)),)
SimG4CMSCalo := self/SimG4CMS/Calo
SimG4CMS/Calo := SimG4CMSCalo
SimG4CMSCalo_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
SimG4CMSCalo_EX_USE := $(foreach d, self cmssw  FWCore/PluginManager SimGeneral/GFlash SimG4Core/Geometry SimG4Core/SensitiveDetector SimG4Core/Notification DataFormats/EcalDetId DataFormats/HcalDetId DataFormats/ForwardDetId DataFormats/Math CondFormats/GeometryObjects CondFormats/HcalObjects SimDataFormats/SimHitMaker SimDataFormats/CaloHit SimDataFormats/CaloTest Geometry/HcalCommonData Geometry/EcalCommonData Geometry/HGCalCommonData Geometry/HGCalTBCommonData Geometry/Records FWCore/ParameterSet FWCore/MessageLogger FWCore/ServiceRegistry CommonTools/UtilAlgos boost clhep geant4core hepmc root rootmath,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
SimG4CMSCalo_EX_LIB   := SimG4CMSCalo
ALL_EXTERNAL_PRODS += SimG4CMSCalo
SimG4CMSCalo_CLASS := LIBRARY
SimG4CMS/Calo_relbigobj+=SimG4CMSCalo
endif
ifeq ($(strip $(SimG4CMSCaloPlugins)),)
SimG4CMSCaloPlugins := self/src/SimG4CMS/Calo/plugins
SimG4CMSCaloPlugins_LOC_USE := self cmssw  CommonTools/UtilAlgos CondFormats/DataRecord DataFormats/EcalDetId DataFormats/HcalDetId FWCore/Framework FWCore/ParameterSet FWCore/MessageLogger FWCore/PluginManager FWCore/ServiceRegistry Geometry/HcalCommonData Geometry/HcalTowerAlgo Geometry/HGCalGeometry Geometry/HGCalTBCommonData Geometry/CaloTopology Geometry/Records SimDataFormats/CaloHit SimDataFormats/Track SimDataFormats/Vertex SimDataFormats/GeneratorProducts SimG4Core/Watcher SimG4CMS/Calo boost root clhep geant4core
ALL_EXTERNAL_PLUGIN_PRODS += SimG4CMSCaloPlugins
SimG4CMS/Calo_relbigobj+=SimG4CMSCaloPlugins
endif
ifeq ($(strip $(FWCore/Version)),)
FWCoreVersion := self/FWCore/Version
FWCore/Version := FWCoreVersion
FWCoreVersion_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
FWCoreVersion_EX_USE := $(foreach d, self cmssw  ,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
FWCoreVersion_EX_LIB   := FWCoreVersion
ALL_EXTERNAL_PRODS += FWCoreVersion
FWCoreVersion_CLASS := LIBRARY
FWCore/Version_relbigobj+=FWCoreVersion
endif
ifeq ($(strip $(DPGAnalysisHcalToolsAuto)),)
DPGAnalysisHcalToolsAuto := self/src/DPGAnalysis/HcalTools/plugins
DPGAnalysisHcalToolsAuto_LOC_USE := self cmssw  root DataFormats/HcalDetId DataFormats/HcalDigi DataFormats/HcalRecHit DataFormats/L1GlobalTrigger CondFormats/HcalObjects CondFormats/DataRecord EventFilter/HcalRawToDigi Geometry/CaloGeometry Geometry/HcalCommonData Geometry/Records Geometry/CaloTopology Geometry/HcalTowerAlgo DataFormats/FEDRawData CalibFormats/HcalObjects CalibCalorimetry/HcalAlgos FWCore/ServiceRegistry CommonTools/UtilAlgos
ALL_EXTERNAL_PLUGIN_PRODS += DPGAnalysisHcalToolsAuto
DPGAnalysis/HcalTools_relbigobj+=DPGAnalysisHcalToolsAuto
endif
ifeq ($(strip $(DPGAnalysis/Skims)),)
DPGAnalysisSkims := self/DPGAnalysis/Skims
DPGAnalysis/Skims := DPGAnalysisSkims
DPGAnalysisSkims_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
DPGAnalysisSkims_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/PluginManager FWCore/ParameterSet FWCore/MessageLogger FWCore/Utilities Geometry/Records Geometry/CSCGeometry DataFormats/CSCDigi DataFormats/CSCRecHit DataFormats/Common DataFormats/MuonDetId DataFormats/DTDigi CondFormats/DTObjects DataFormats/RPCRecHit DataFormats/EcalDetId DataFormats/EcalRecHit DataFormats/L1GlobalTrigger DataFormats/Scalers DataFormats/TrackReco DataFormats/MuonReco DataFormats/VertexReco DataFormats/METReco DataFormats/JetReco DataFormats/EgammaCandidates DataFormats/HcalIsolatedTrack Geometry/RPCGeometry DataFormats/L1Trigger DataFormats/TrackerRecHit2D root HLTrigger/HLTcore DataFormats/HcalRecHit DataFormats/EgammaReco PhysicsTools/SelectorUtils DataFormats/Provenance DataFormats/OnlineMetaData,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += DPGAnalysisSkims
DPGAnalysisSkims_CLASS := LIBRARY
DPGAnalysis/Skims_relbigobj+=DPGAnalysisSkims
endif
ifeq ($(strip $(DQM/Integration)),)
src_DQM_Integration := self/DQM/Integration
DQM/Integration  := src_DQM_Integration
src_DQM_Integration_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
src_DQM_Integration_EX_USE := $(foreach d, self cmssw CoralBase RelationalAccess,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += src_DQM_Integration
endif

ifeq ($(strip $(DQM/SiPixelMonitorTrack)),)
DQMSiPixelMonitorTrack := self/DQM/SiPixelMonitorTrack
DQM/SiPixelMonitorTrack := DQMSiPixelMonitorTrack
DQMSiPixelMonitorTrack_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
DQMSiPixelMonitorTrack_EX_USE := $(foreach d, self cmssw  FWCore/Framework DQMServices/Core DQM/SiPixelCommon DataFormats/TrackerRecHit2D Geometry/CommonDetUnit Geometry/Records Geometry/TrackerGeometryBuilder TrackingTools/TrackFitters RecoTracker/MeasurementDet TrackingTools/KalmanUpdators TrackingTools/MeasurementDet TrackingTools/Records TrackingTools/TransientTrack boost,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += DQMSiPixelMonitorTrack
DQMSiPixelMonitorTrack_CLASS := LIBRARY
DQM/SiPixelMonitorTrack_relbigobj+=DQMSiPixelMonitorTrack
endif
ifeq ($(strip $(DQM/TrackingMonitor)),)
DQMTrackingMonitor := self/DQM/TrackingMonitor
DQM/TrackingMonitor := DQMTrackingMonitor
DQMTrackingMonitor_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
DQMTrackingMonitor_EX_USE := $(foreach d, self cmssw  TrackingTools/Records FWCore/Framework FWCore/PluginManager FWCore/ParameterSet DQMServices/Core CommonTools/TriggerUtils DataFormats/TrackReco DataFormats/TrackCandidate DataFormats/Luminosity DataFormats/OnlineMetaData DataFormats/VertexReco DataFormats/PatCandidates TrackingTools/TransientTrackingRecHit TrackingTools/TransientTrack TrackingTools/IPTools TrackPropagation/SteppingHelixPropagator DataFormats/MuonReco Geometry/RPCGeometry RecoMuon/GlobalTrackingTools RecoVertex/AdaptiveVertexFit,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += DQMTrackingMonitor
DQMTrackingMonitor_CLASS := LIBRARY
DQM/TrackingMonitor_relbigobj+=DQMTrackingMonitor
endif
ifeq ($(strip $(DQMSiPixelPhase1TrackAuto)),)
DQMSiPixelPhase1TrackAuto := self/src/DQM/SiPixelPhase1Track/plugins
DQMSiPixelPhase1TrackAuto_LOC_USE := self cmssw  DQM/SiPixelPhase1Common DataFormats/TrackerRecHit2D RecoTracker/PixelLowPtUtilities CondFormats/SiPixelTransient Alignment/OfflineValidation
ALL_EXTERNAL_PLUGIN_PRODS += DQMSiPixelPhase1TrackAuto
DQM/SiPixelPhase1Track_relbigobj+=DQMSiPixelPhase1TrackAuto
endif
ifeq ($(strip $(Fireworks/Geometry)),)
FireworksGeometry := self/Fireworks/Geometry
Fireworks/Geometry := FireworksGeometry
FireworksGeometry_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
FireworksGeometry_EX_USE := $(foreach d, self cmssw  FWCore/PluginManager FWCore/Framework Geometry/CommonDetUnit Geometry/CaloGeometry Geometry/HGCalGeometry Geometry/DTGeometry Geometry/CSCGeometry Geometry/RPCGeometry Geometry/GEMGeometry Geometry/TrackerGeometryBuilder Geometry/MTDGeometryBuilder Geometry/Records DataFormats/GeometrySurface DataFormats/MuonDetId RecoLocalCalo/HGCalRecAlgos Fireworks/Core rootcore rootgeom rooteve rootphysics,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
FireworksGeometry_EX_LIB   := FireworksGeometry
ALL_EXTERNAL_PRODS += FireworksGeometry
FireworksGeometry_CLASS := LIBRARY
Fireworks/Geometry_relbigobj+=FireworksGeometry
endif
ifeq ($(strip $(FireworksDisplayGeomPlugin)),)
FireworksDisplayGeomPlugin := self/src/Fireworks/Geometry/plugins
FireworksDisplayGeomPlugin_LOC_USE := self cmssw  FWCore/Framework Fireworks/Geometry Fireworks/Eve rooteve rootgeom rootphysics rootrgl MagneticField/Engine MagneticField/Records
ALL_EXTERNAL_PLUGIN_PRODS += FireworksDisplayGeomPlugin
Fireworks/Geometry_relbigobj+=FireworksDisplayGeomPlugin
endif
ifeq ($(strip $(FireworksGeometryDumpFWRecoGeometryPlugin)),)
FireworksGeometryDumpFWRecoGeometryPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryDumpFWRecoGeometryPlugin_LOC_USE := self cmssw  Fireworks/Geometry rooteve rootgeom rootcore FWCore/Framework FWCore/ParameterSet Geometry/CaloGeometry Geometry/DTGeometry Geometry/CSCGeometry Geometry/RPCGeometry Geometry/TrackerGeometryBuilder Geometry/Records
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryDumpFWRecoGeometryPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryDumpFWRecoGeometryPlugin
endif
ifeq ($(strip $(FireworksGeometryDumpFWTGeoRecoGeometryPlugin)),)
FireworksGeometryDumpFWTGeoRecoGeometryPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryDumpFWTGeoRecoGeometryPlugin_LOC_USE := self cmssw  Fireworks/Geometry rooteve rootgeom rootcore FWCore/Framework FWCore/ParameterSet Geometry/CaloGeometry Geometry/DTGeometry Geometry/CSCGeometry Geometry/RPCGeometry Geometry/TrackerGeometryBuilder Geometry/Records
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryDumpFWTGeoRecoGeometryPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryDumpFWTGeoRecoGeometryPlugin
endif
ifeq ($(strip $(FireworksGeometryDumpSimGeometryPlugin)),)
FireworksGeometryDumpSimGeometryPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryDumpSimGeometryPlugin_LOC_USE := self cmssw  Fireworks/Geometry FWCore/Framework FWCore/ParameterSet rootgeom
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryDumpSimGeometryPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryDumpSimGeometryPlugin
endif
ifeq ($(strip $(FireworksGeometryFWRecoGeometryESProducerPlugin)),)
FireworksGeometryFWRecoGeometryESProducerPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryFWRecoGeometryESProducerPlugin_LOC_USE := self cmssw  Fireworks/Geometry
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryFWRecoGeometryESProducerPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryFWRecoGeometryESProducerPlugin
endif
ifeq ($(strip $(FireworksGeometryFWTGeoRecoGeometryESProducerPlugin)),)
FireworksGeometryFWTGeoRecoGeometryESProducerPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryFWTGeoRecoGeometryESProducerPlugin_LOC_USE := self cmssw  Fireworks/Geometry
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryFWTGeoRecoGeometryESProducerPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryFWTGeoRecoGeometryESProducerPlugin
endif
ifeq ($(strip $(FireworksGeometryMFProducerPlugin)),)
FireworksGeometryMFProducerPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryMFProducerPlugin_LOC_USE := self cmssw  FWCore/Framework FWCore/ParameterSet clhep MagneticField/Engine MagneticField/Records rootgpad
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryMFProducerPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryMFProducerPlugin
endif
ifeq ($(strip $(FireworksGeometryPlugins)),)
FireworksGeometryPlugins := self/src/Fireworks/Geometry/plugins
FireworksGeometryPlugins_LOC_USE := self cmssw  Geometry/Records Fireworks/Geometry rootgpad rooteve rootgeom
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryPlugins
Fireworks/Geometry_relbigobj+=FireworksGeometryPlugins
endif
ifeq ($(strip $(FireworksGeometryTGeoMgrFromDddPlugin)),)
FireworksGeometryTGeoMgrFromDddPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryTGeoMgrFromDddPlugin_LOC_USE := self cmssw  DetectorDescription/Core Fireworks/Geometry
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryTGeoMgrFromDddPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryTGeoMgrFromDddPlugin
endif
ifeq ($(strip $(FireworksGeometryValidateGeometryPlugin)),)
FireworksGeometryValidateGeometryPlugin := self/src/Fireworks/Geometry/plugins
FireworksGeometryValidateGeometryPlugin_LOC_USE := self cmssw  FWCore/Framework Geometry/RPCGeometry Geometry/DTGeometry Geometry/CSCGeometry Geometry/CaloGeometry Geometry/TrackerGeometryBuilder Geometry/Records Fireworks/Core Fireworks/Tracks rootcore rootgeom
ALL_EXTERNAL_PLUGIN_PRODS += FireworksGeometryValidateGeometryPlugin
Fireworks/Geometry_relbigobj+=FireworksGeometryValidateGeometryPlugin
endif
ifeq ($(strip $(PhysicsTools/HepMCCandAlgos)),)
PhysicsToolsHepMCCandAlgos := self/PhysicsTools/HepMCCandAlgos
PhysicsTools/HepMCCandAlgos := PhysicsToolsHepMCCandAlgos
PhysicsToolsHepMCCandAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
PhysicsToolsHepMCCandAlgos_EX_USE := $(foreach d, self cmssw  SimGeneral/HepPDTRecord DataFormats/Candidate DataFormats/HepMCCandidate CommonTools/UtilAlgos hepmc eigen clhep,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
PhysicsToolsHepMCCandAlgos_EX_LIB   := PhysicsToolsHepMCCandAlgos
ALL_EXTERNAL_PRODS += PhysicsToolsHepMCCandAlgos
PhysicsToolsHepMCCandAlgos_CLASS := LIBRARY
PhysicsTools/HepMCCandAlgos_relbigobj+=PhysicsToolsHepMCCandAlgos
endif
ifeq ($(strip $(PhysicsToolsHepMCCandAlgos_plugins)),)
PhysicsToolsHepMCCandAlgos_plugins := self/src/PhysicsTools/HepMCCandAlgos/plugins
PhysicsToolsHepMCCandAlgos_plugins_LOC_USE := self cmssw  DataFormats/Common FWCore/Framework FWCore/ParameterSet FWCore/MessageLogger DataFormats/HepMCCandidate SimDataFormats/GeneratorProducts SimGeneral/HepPDTRecord SimDataFormats/Track PhysicsTools/HepMCCandAlgos PhysicsTools/JetMCUtils CommonTools/Utils
ALL_EXTERNAL_PLUGIN_PRODS += PhysicsToolsHepMCCandAlgos_plugins
PhysicsTools/HepMCCandAlgos_relbigobj+=PhysicsToolsHepMCCandAlgos_plugins
endif
ifeq ($(strip $(PhysicsTools/Heppy)),)
PhysicsToolsHeppy := self/PhysicsTools/Heppy
PhysicsTools/Heppy := PhysicsToolsHeppy
PhysicsToolsHeppy_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
PhysicsToolsHeppy_EX_USE := $(foreach d, self cmssw  root rootcore clhepheader DataFormats/Candidate DataFormats/PatCandidates DataFormats/HepMCCandidate fastjet ktjet EgammaAnalysis/ElectronTools CommonTools/CandUtils CommonTools/Utils DataFormats/Common DataFormats/Math FWCore/Common FWCore/ParameterSet FWCore/Utilities SimDataFormats/GeneratorProducts boost lhapdf,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
PhysicsToolsHeppy_LCGDICTS  := x 
PhysicsToolsHeppy_EX_LIB   := PhysicsToolsHeppy
ALL_EXTERNAL_PRODS += PhysicsToolsHeppy
PhysicsToolsHeppy_CLASS := LIBRARY
PhysicsTools/Heppy_relbigobj+=PhysicsToolsHeppy
endif
ifeq ($(strip $(PhysicsTools/PatAlgos)),)
PhysicsToolsPatAlgos := self/PhysicsTools/PatAlgos
PhysicsTools/PatAlgos := PhysicsToolsPatAlgos
PhysicsToolsPatAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
PhysicsToolsPatAlgos_EX_USE := $(foreach d, self cmssw  CommonTools/CandAlgos CommonTools/MVAUtils DataFormats/Candidate DataFormats/Common DataFormats/JetReco DataFormats/Math DataFormats/MuonReco DataFormats/PatCandidates DataFormats/TrackReco DataFormats/VertexReco JetMETCorrections/JetCorrector FWCore/Framework FWCore/ParameterSet FWCore/Utilities PhysicsTools/IsolationAlgos PhysicsTools/PatUtils PhysicsTools/TensorFlow PhysicsTools/ONNXRuntime PhysicsTools/XGBoost TrackingTools/Records clhep xgboost,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
PhysicsToolsPatAlgos_EX_LIB   := PhysicsToolsPatAlgos
ALL_EXTERNAL_PRODS += PhysicsToolsPatAlgos
PhysicsToolsPatAlgos_CLASS := LIBRARY
PhysicsTools/PatAlgos_relbigobj+=PhysicsToolsPatAlgos
endif
ifeq ($(strip $(PhysicsToolsPatAlgos_plugins)),)
PhysicsToolsPatAlgos_plugins := self/src/PhysicsTools/PatAlgos/plugins
PhysicsToolsPatAlgos_plugins_LOC_USE := self cmssw  PhysicsTools/PatAlgos FWCore/Framework FWCore/ParameterSet FWCore/MessageLogger L1Trigger/GlobalTriggerAnalyzer HLTrigger/HLTcore DataFormats/PatCandidates DataFormats/BTauReco DataFormats/Common DataFormats/JetMatching DataFormats/JetReco DataFormats/MuonReco DataFormats/TrackReco DataFormats/Candidate DataFormats/HeavyIonEvent DataFormats/HepMCCandidate PhysicsTools/PatUtils CondFormats/JetMETObjects CondFormats/HcalObjects CondFormats/DataRecord CommonTools/Egamma JetMETCorrections/Objects JetMETCorrections/JetCorrector TrackingTools/TransientTrack RecoEgamma/EgammaTools SimDataFormats/Track SimDataFormats/Vertex SimDataFormats/PileupSummaryInfo SimGeneral/HepPDTRecord RecoMET/METAlgorithms RecoTracker/DeDx TrackingTools/IPTools TrackingTools/Records RecoTauTag/RecoTau root
ALL_EXTERNAL_PLUGIN_PRODS += PhysicsToolsPatAlgos_plugins
PhysicsTools/PatAlgos_relbigobj+=PhysicsToolsPatAlgos_plugins
endif
ifeq ($(strip $(PhysicsTools/JetMCAlgos)),)
PhysicsToolsJetMCAlgos := self/PhysicsTools/JetMCAlgos
PhysicsTools/JetMCAlgos := PhysicsToolsJetMCAlgos
PhysicsToolsJetMCAlgos_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
PhysicsToolsJetMCAlgos_EX_USE := $(foreach d, self cmssw  PhysicsTools/JetMCUtils DataFormats/Common DataFormats/HepMCCandidate,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
PhysicsToolsJetMCAlgos_EX_LIB   := PhysicsToolsJetMCAlgos
ALL_EXTERNAL_PRODS += PhysicsToolsJetMCAlgos
PhysicsToolsJetMCAlgos_CLASS := LIBRARY
PhysicsTools/JetMCAlgos_relbigobj+=PhysicsToolsJetMCAlgos
endif
ifeq ($(strip $(PhysicsToolsJetMCAlgosPlugins)),)
PhysicsToolsJetMCAlgosPlugins := self/src/PhysicsTools/JetMCAlgos/plugins
PhysicsToolsJetMCAlgosPlugins_LOC_USE := self cmssw  FWCore/Framework FWCore/PluginManager FWCore/ParameterSet PhysicsTools/JetMCAlgos PhysicsTools/JetMCUtils PhysicsTools/HepMCCandAlgos SimDataFormats/GeneratorProducts DataFormats/HepMCCandidate CommonTools/CandUtils CommonTools/UtilAlgos DataFormats/Candidate DataFormats/Common DataFormats/JetMatching DataFormats/JetReco DataFormats/Math DataFormats/ParticleFlowCandidate FWCore/Common FWCore/MessageLogger FWCore/Utilities fastjet
ALL_EXTERNAL_PLUGIN_PRODS += PhysicsToolsJetMCAlgosPlugins
PhysicsTools/JetMCAlgos_relbigobj+=PhysicsToolsJetMCAlgosPlugins
endif
ifeq ($(strip $(PhysicsTools/TagAndProbe)),)
PhysicsToolsTagAndProbe := self/PhysicsTools/TagAndProbe
PhysicsTools/TagAndProbe := PhysicsToolsTagAndProbe
PhysicsToolsTagAndProbe_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
PhysicsToolsTagAndProbe_EX_USE := $(foreach d, self cmssw  roofitcore FWCore/MessageLogger FWCore/ParameterSet DataFormats/METReco DataFormats/Math DataFormats/Candidate DataFormats/Common CommonTools/Utils CommonTools/UtilAlgos DataFormats/BeamSpot DataFormats/HLTReco DataFormats/PatCandidates DataFormats/VertexReco FWCore/Common FWCore/Framework FWCore/ServiceRegistry FWCore/Utilities HLTrigger/HLTcore SimDataFormats/GeneratorProducts SimDataFormats/PileupSummaryInfo,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
PhysicsToolsTagAndProbe_LCGDICTS  := x 
PhysicsToolsTagAndProbe_EX_LIB   := PhysicsToolsTagAndProbe
ALL_EXTERNAL_PRODS += PhysicsToolsTagAndProbe
PhysicsToolsTagAndProbe_CLASS := LIBRARY
PhysicsTools/TagAndProbe_relbigobj+=PhysicsToolsTagAndProbe
endif
ifeq ($(strip $(PhysicsToolsTagAndProbe_plugins)),)
PhysicsToolsTagAndProbe_plugins := self/src/PhysicsTools/TagAndProbe/plugins
PhysicsToolsTagAndProbe_plugins_LOC_USE := self cmssw  FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/ServiceRegistry DataFormats/TrackReco DataFormats/EgammaReco DataFormats/Math DataFormats/MuonReco DataFormats/EgammaCandidates DataFormats/RecoCandidate DataFormats/Candidate DataFormats/Common PhysicsTools/TagAndProbe DataFormats/PatCandidates DataFormats/HcalIsolatedTrack PhysicsTools/PatUtils
ALL_EXTERNAL_PLUGIN_PRODS += PhysicsToolsTagAndProbe_plugins
PhysicsTools/TagAndProbe_relbigobj+=PhysicsToolsTagAndProbe_plugins
endif
ifeq ($(strip $(RecoJets/JetAnalyzers)),)
RecoJetsJetAnalyzers := self/RecoJets/JetAnalyzers
RecoJets/JetAnalyzers := RecoJetsJetAnalyzers
RecoJetsJetAnalyzers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoJetsJetAnalyzers_EX_USE := $(foreach d, self cmssw  FWCore/Framework FWCore/ParameterSet root DataFormats/Candidate DataFormats/JetReco DataFormats/HepMCCandidate DataFormats/CaloTowers DataFormats/HcalRecHit DataFormats/HcalDigi DataFormats/HcalDetId DataFormats/FEDRawData SimDataFormats/GeneratorProducts CommonTools/UtilAlgos FWCore/ServiceRegistry PhysicsTools/SelectorUtils,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
ALL_EXTERNAL_PRODS += RecoJetsJetAnalyzers
RecoJetsJetAnalyzers_CLASS := LIBRARY
RecoJets/JetAnalyzers_relbigobj+=RecoJetsJetAnalyzers
endif
ifeq ($(strip $(RecoJets/JetProducers)),)
RecoJetsJetProducers := self/RecoJets/JetProducers
RecoJets/JetProducers := RecoJetsJetProducers
RecoJetsJetProducers_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoJetsJetProducers_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoJetsJetProducers_EX_USE := $(foreach d, self cmssw  boost FWCore/Framework DataFormats/JetReco DataFormats/PatCandidates Geometry/CaloGeometry Geometry/CaloTopology Geometry/Records SimDataFormats/CaloHit SimDataFormats/Vertex SimDataFormats/Track RecoJets/JetAlgorithms JetMETCorrections/JetCorrector DataFormats/CastorReco CommonTools/MVAUtils fastjet vdt_headers boost_serialization,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoJetsJetProducers_EX_LIB   := RecoJetsJetProducers
ALL_EXTERNAL_PRODS += RecoJetsJetProducers
RecoJetsJetProducers_CLASS := LIBRARY
RecoJets/JetProducers_relbigobj+=RecoJetsJetProducers
endif
ifeq ($(strip $(RecoJetsJetProducers_plugins)),)
RecoJetsJetProducers_plugins := self/src/RecoJets/JetProducers/plugins
RecoJetsJetProducers_plugins_LOC_USE := self cmssw  RecoJets/JetProducers RecoJets/JetAlgorithms RecoEgamma/EgammaIsolationAlgos FWCore/Framework FWCore/ParameterSet DataFormats/BTauReco DataFormats/JetReco DataFormats/VertexReco DataFormats/HcalRecHit DataFormats/EcalRecHit Geometry/CaloGeometry Geometry/Records CommonTools/UtilAlgos CondFormats/JetMETObjects CondFormats/EcalObjects CondFormats/DataRecord JetMETCorrections/Objects fastjet fastjet-contrib
ALL_EXTERNAL_PLUGIN_PRODS += RecoJetsJetProducers_plugins
RecoJets/JetProducers_relbigobj+=RecoJetsJetProducers_plugins
endif
ifeq ($(strip $(RecoParticleFlow/PFProducer)),)
RecoParticleFlowPFProducer := self/RecoParticleFlow/PFProducer
RecoParticleFlow/PFProducer := RecoParticleFlowPFProducer
RecoParticleFlowPFProducer_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoParticleFlowPFProducer_EX_USE := $(foreach d, self cmssw  CondFormats/GBRForest CommonTools/MVAUtils CommonTools/ParticleFlow DataFormats/CaloRecHit DataFormats/Common DataFormats/EgammaCandidates DataFormats/ParticleFlowCandidate DataFormats/ParticleFlowReco DataFormats/TrackReco DataFormats/VertexReco DataFormats/MuonReco DataFormats/EcalDetId RecoParticleFlow/PFClusterTools RecoParticleFlow/PFTracking RecoEcal/EgammaCoreTools boost clhep rootmath onnxruntime,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoParticleFlowPFProducer_EX_LIB   := RecoParticleFlowPFProducer
ALL_EXTERNAL_PRODS += RecoParticleFlowPFProducer
RecoParticleFlowPFProducer_CLASS := LIBRARY
RecoParticleFlow/PFProducer_relbigobj+=RecoParticleFlowPFProducer
endif
ifeq ($(strip $(RecoParticleFlowPFProducerPlugins)),)
RecoParticleFlowPFProducerPlugins := self/src/RecoParticleFlow/PFProducer/plugins
RecoParticleFlowPFProducerPlugins_LOC_USE := self cmssw  CommonTools/ParticleFlow CondFormats/DataRecord CondFormats/PhysicsToolsObjects DataFormats/CaloRecHit DataFormats/Common DataFormats/EgammaReco DataFormats/GsfTrackReco DataFormats/MuonReco DataFormats/ParticleFlowCandidate DataFormats/ParticleFlowReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities RecoParticleFlow/PFClusterTools RecoParticleFlow/PFProducer RecoParticleFlow/PFTracking RecoEcal/EgammaCoreTools PhysicsTools/ONNXRuntime
ALL_EXTERNAL_PLUGIN_PRODS += RecoParticleFlowPFProducerPlugins
RecoParticleFlow/PFProducer_relbigobj+=RecoParticleFlowPFProducerPlugins
endif
ifeq ($(strip $(RecoParticleFlowPFProducerPlugins_importers)),)
RecoParticleFlowPFProducerPlugins_importers := self/src/RecoParticleFlow/PFProducer/plugins
RecoParticleFlowPFProducerPlugins_importers_LOC_USE := self cmssw  CondFormats/DataRecord CondFormats/PhysicsToolsObjects DataFormats/CaloRecHit DataFormats/Common DataFormats/EgammaReco DataFormats/GsfTrackReco DataFormats/MuonReco DataFormats/ParticleFlowCandidate DataFormats/ParticleFlowReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities RecoParticleFlow/PFClusterTools RecoParticleFlow/PFProducer RecoParticleFlow/PFTracking RecoEcal/EgammaCoreTools RecoEgamma/EgammaIsolationAlgos
ALL_EXTERNAL_PLUGIN_PRODS += RecoParticleFlowPFProducerPlugins_importers
RecoParticleFlow/PFProducer_relbigobj+=RecoParticleFlowPFProducerPlugins_importers
endif
ifeq ($(strip $(RecoParticleFlowPFProducerPlugins_kdtrees)),)
RecoParticleFlowPFProducerPlugins_kdtrees := self/src/RecoParticleFlow/PFProducer/plugins
RecoParticleFlowPFProducerPlugins_kdtrees_LOC_USE := self cmssw  CommonTools/RecoAlgos CondFormats/DataRecord CondFormats/PhysicsToolsObjects DataFormats/CaloRecHit DataFormats/Common DataFormats/EgammaReco DataFormats/GsfTrackReco DataFormats/MuonReco DataFormats/ParticleFlowCandidate DataFormats/ParticleFlowReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities RecoParticleFlow/PFClusterTools RecoParticleFlow/PFProducer RecoEcal/EgammaCoreTools
ALL_EXTERNAL_PLUGIN_PRODS += RecoParticleFlowPFProducerPlugins_kdtrees
RecoParticleFlow/PFProducer_relbigobj+=RecoParticleFlowPFProducerPlugins_kdtrees
endif
ifeq ($(strip $(RecoParticleFlowPFProducerPlugins_linkers)),)
RecoParticleFlowPFProducerPlugins_linkers := self/src/RecoParticleFlow/PFProducer/plugins
RecoParticleFlowPFProducerPlugins_linkers_LOC_USE := self cmssw  CondFormats/DataRecord CondFormats/PhysicsToolsObjects DataFormats/CaloRecHit DataFormats/Common DataFormats/EgammaReco DataFormats/GsfTrackReco DataFormats/MuonReco DataFormats/ParticleFlowCandidate DataFormats/ParticleFlowReco FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities RecoParticleFlow/PFClusterTools RecoParticleFlow/PFProducer RecoEcal/EgammaCoreTools
ALL_EXTERNAL_PLUGIN_PRODS += RecoParticleFlowPFProducerPlugins_linkers
RecoParticleFlow/PFProducer_relbigobj+=RecoParticleFlowPFProducerPlugins_linkers
endif
ifeq ($(strip $(RecoParticleFlow/PFTracking)),)
RecoParticleFlowPFTracking := self/RecoParticleFlow/PFTracking
RecoParticleFlow/PFTracking := RecoParticleFlowPFTracking
RecoParticleFlowPFTracking_BuildFile    := $(RELEASETOP)/.SCRAM/$(SCRAM_ARCH)/MakeData/DirCache.mk
RecoParticleFlowPFTracking_EX_FLAGS_USE_SOURCE_ONLY   := Geometry/CommonDetUnit
RecoParticleFlowPFTracking_EX_USE := $(foreach d, self cmssw  RecoVertex/KalmanVertexFit DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/GsfTrackReco DataFormats/Math DataFormats/ParticleFlowReco DataFormats/TrackReco DataFormats/SiPixelDetId DataFormats/SiStripDetId DataFormats/BeamSpot Geometry/TrackerGeometryBuilder Geometry/Records FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet CommonTools/BaseParticlePropagator RecoParticleFlow/PFClusterTools TrackingTools/GsfTools TrackingTools/PatternTools TrackingTools/TrajectoryState TrackingTools/TransientTrack TrackingTools/TrajectoryParametrization RecoVertex/VertexPrimitives RecoVertex/AdaptiveVertexFit TrackingTools/IPTools DataFormats/VertexReco CondFormats/GBRForest CommonTools/MVAUtils rootcore,$(if $($(d)_EX_FLAGS_NO_RECURSIVE_EXPORT),,$d))
RecoParticleFlowPFTracking_EX_LIB   := RecoParticleFlowPFTracking
ALL_EXTERNAL_PRODS += RecoParticleFlowPFTracking
RecoParticleFlowPFTracking_CLASS := LIBRARY
RecoParticleFlow/PFTracking_relbigobj+=RecoParticleFlowPFTracking
endif
ifeq ($(strip $(RecoParticleFlowPFTrackingPlugins)),)
RecoParticleFlowPFTrackingPlugins := self/src/RecoParticleFlow/PFTracking/plugins
RecoParticleFlowPFTrackingPlugins_LOC_USE := self cmssw  CommonTools/UtilAlgos CommonTools/BaseParticlePropagator DataFormats/Common DataFormats/EgammaCandidates DataFormats/EgammaReco DataFormats/GsfTrackReco DataFormats/ParticleFlowReco DataFormats/RecoCandidate DataFormats/TrackReco DataFormats/TrajectorySeed FWCore/Framework FWCore/MessageLogger FWCore/Utilities MagneticField/Engine MagneticField/Records RecoParticleFlow/PFTracking RecoTracker/TransientTrackingRecHit Geometry/HGCalGeometry Geometry/Records TrackingTools/MaterialEffects TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrackFitters
ALL_EXTERNAL_PLUGIN_PRODS += RecoParticleFlowPFTrackingPlugins
RecoParticleFlow/PFTracking_relbigobj+=RecoParticleFlowPFTrackingPlugins
endif
ifeq ($(strip $(RecoParticleFlowPFProducerSimPlugins)),)
RecoParticleFlowPFProducerSimPlugins := self/src/RecoParticleFlow/PFSimProducer/plugins
RecoParticleFlowPFProducerSimPlugins_LOC_USE := self cmssw  DataFormats/EcalDetId TrackingTools/MaterialEffects DataFormats/EcalRecHit DataFormats/GeometrySurface DataFormats/GeometryVector DataFormats/ParticleFlowReco DataFormats/TrackReco DataFormats/TrackerRecHit2D FWCore/Framework FWCore/MessageLogger FWCore/ParameterSet FWCore/Utilities FastSimulation/Event Geometry/Records Geometry/TrackerGeometryBuilder MagneticField/Engine MagneticField/Records RecoParticleFlow/PFClusterTools RecoParticleFlow/PFProducer SimDataFormats/CaloHit SimGeneral/HepPDTRecord SimTracker/TrackAssociation TrackingTools/GeomPropagators TrackingTools/PatternTools TrackingTools/Records TrackingTools/TrajectoryState DataFormats/GsfTrackReco DataFormats/TrackingRecHit DataFormats/TrajectorySeed FastSimulation/ParticlePropagator FastSimulation/TrackerSetup FastSimulation/TrajectoryManager RecoParticleFlow/PFTracking RecoTracker/Record RecoTracker/TkDetLayers RecoTracker/TkSeedGenerator RecoTracker/TransientTrackingRecHit TrackingTools/DetLayers TrackingTools/KalmanUpdators
ALL_EXTERNAL_PLUGIN_PRODS += RecoParticleFlowPFProducerSimPlugins
RecoParticleFlow/PFSimProducer_relbigobj+=RecoParticleFlowPFProducerSimPlugins
endif

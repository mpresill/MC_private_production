ALL_TOOLS      += coral
ALL_SCRAM_PROJECTS += coral
coral_EX_INCLUDE := /cvmfs/cms.cern.ch/el8_amd64_gcc12/cms/coral/CORAL_2_3_21-10e62487bc7681dc8f3852516a93cd83/include/LCG
coral_EX_USE := root_cxxdefaults
coral_ORDER := 98000


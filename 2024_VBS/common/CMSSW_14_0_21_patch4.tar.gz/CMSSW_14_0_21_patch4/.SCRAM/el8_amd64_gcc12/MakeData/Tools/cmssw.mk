ALL_TOOLS      += cmssw
ALL_SCRAM_PROJECTS += cmssw
cmssw_EX_LIBDIR := /cvmfs/cms.cern.ch/el8_amd64_gcc12/cms/cmssw/CMSSW_14_0_21/biglib/el8_amd64_gcc12 /cvmfs/cms.cern.ch/el8_amd64_gcc12/cms/cmssw/CMSSW_14_0_21/lib/el8_amd64_gcc12
cmssw_EX_USE := root_cxxdefaults
cmssw_ORDER := 96000

